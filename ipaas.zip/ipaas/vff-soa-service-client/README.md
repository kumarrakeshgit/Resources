# VFF SOA Service Client

## Instructions

The generation of client code is complicated somewhat by the fact that access to the hosted WSDL
requires an SSH tunnel through a VPN tunnel, connecting to a bastion host in AWS and then on to the
underlying VA SOA services. The following outlines the necessary steps to generate the client code.

*n.b. The underlying SOA services accessible from the dev account currently have a tendency of
timing out. When this occurs, simply try again and hope for the best. It may be worth considering
hosting the WSDLs locally within this project to avoid the tunnels and timeout shenanigans in the
future.*

### Preliminary Steps
1. Download the [Virgin f5 VPN client](https://versent.box.com/s/qrbmxzko3331fpbxxlqm8u33xtximphz)
1. Ensure you have a Virgin allocated username, password and pin and can receive RSA tokens
1. Obtain the iPaaS Dev Bastion private key from the customers-velocity-ipaas 1Password vault 

### Create Proxy

1. Connect to Virgin VPN via f5 VPN client
1. Create SOCKS proxy to bastion server
   1. `ssh -N -D 9999 -i ~/.ssh/vff-bastion.key ubuntu@10.113.136.200`

### Run

`mvn generate-sources`

## Notes

* The WSDLs hosted by Virgin reference URLs with an internal hostname, rather than the ingress
controller hostname. To workaround this, the `soa-url-rewrite.cat` XML catalog is used by the
`wsdl2java` tooling to rewrite the URLs to use the ingress controller hostname instead.

