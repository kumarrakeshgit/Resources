# Velocity Microservice - /profile-api

Profile API



* `ENVIRONMENT_NAME` - The name of the environment this service is running in.
* `ENVIRONMENT_NUMBER` - The environment number associated with the running service.
* `AWS_ACCOUNT_ID` - The AWS account ID that the running service will be associated with.
* `AWS_REGION` - The AWS region that the service will be running in.


* `src/main/filtered-resources/profile-api.properties`
* `src/main/resources/config/application.yml`


The built service can either be run directly:

```sh
ENVIRONMENT_NAME=test ENVIRONMENT_NUMBER=99 AWS_ACCOUNT_ID=123123 AWS_REGION=us-west-2 \
  VFF_ESB_USERNAME=test VFF_ESB_PASSWORD=pass \
  VFF_GETMEMBERPROFILE_URL=http://localhost:8882/v1/mocks/GetLoyaltyMemberProfile \
  VFF_UPDATEMEMBERPROFILE_URL=http://localhost:8882/v1/mocks/UpdateLoyaltyMemberProfile \
  GIT_COMMIT=afsas GIT_BRANCH=master GIT_URL=http \
  java -jar ./target/profile-api-1.1.4.jar
```

[Note: Point environment variables `VFF_GETMEMBERPROFILE_URL` and `VFF_UPDATEMEMBERPROFILE_URL` at your running vff-mock-server or forwarded ports of the real one. If you use the mock server, you don't need to define `VFF_ESB_USERNAME` and `VFF_ESB_PASSWORD`.]

or via Docker:

```sh
docker run --rm -it -p9080:9080 \
  -e ENVIRONMENT_NAME=test -e ENVIRONMENT_NUMBER=99 -e AWS_ACCOUNT_ID=123123 -e AWS_REGION=us-west-2 \
  -e VFF_ESB_USERNAME=test -e VFF_ESB_PASSWORD=pass \
  -e VFF_GETMEMBERPROFILE_URL=http://x.x.x.x:8882/v1/mocks/GetLoyaltyMemberProfile \
  -e VFF_UPDATEMEMBERPROFILE_URL=http://x.x.x.x:8882/v1/mocks/UpdateLoyaltyMemberProfile \
  -e GIT_COMMIT=afsas -e GIT_BRANCH=master -e GIT_URL=http \
  vff-ms-profile-api-v1:1.1.4
```

[Note: It's also possible to run the Docker container against vff-mock-server. Just make sure you start vff-mock-server with "-l x.x.x.x" (no quotes), where x.x.x.x is the IP address (not localhost) of your computer or the computer running the mock server.]

To avoid the need for providing a signed JWT, it can be useful to pass in a test member ID as an
argument `--jwt-auth.test-member-id=123456`. A test correlation ID can also be provided as a command
line argument, removing the need for including it as a HTTP header while testing locally
`--jwt-auth.test-correlation-id=abcdef`.



```sh
mvn test
```


Running the following will produce an executable jar along with a Docker image

```sh
mvn package
```

If Docker is not installed locally, or you don't wish to build a Docker image you can run with the following option

```sh
mvn package -Ddockerfile.build.skip=true
```
To run with all integration tests make sure vff-mock-server is running. To skip integration tests use

``` sh
mvn -DskipITs=true package
```

[Include any other links to relevant architecture, business logic, deployment docs, etc in Confluence or elsewhere]