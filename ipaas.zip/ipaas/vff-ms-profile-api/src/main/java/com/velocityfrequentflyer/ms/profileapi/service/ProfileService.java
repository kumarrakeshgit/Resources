package com.velocityfrequentflyer.ms.profileapi.service;

import static com.google.common.base.Preconditions.checkNotNull;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.velocityfrequentflyer.ms.config.HeadersConfig;
import com.velocityfrequentflyer.ms.exception.ServiceProviderException;
import com.velocityfrequentflyer.ms.profileapi.dto.Profile;
import com.velocityfrequentflyer.ms.profileapi.dto.ProfileUpdated;
import com.velocityfrequentflyer.ms.profileapi.mapping.ProfileMapper;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRQ;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRS;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRQ;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRS;
import com.virginaustralia.model.schema.utility.TransactionRequestHeaderType;
import com.virginaustralia.model.schema.utility.TransactionResponseHeaderType;
import com.virginaustralia.service.contract.loyalty_membership_management.GetLoyaltyMemberProfilePpt;
import com.virginaustralia.service.contract.loyalty_membership_management.GetMemberProfileException;
import com.virginaustralia.service.contract.loyalty_membership_management.UpdateLoyaltyMemberProfilePpt;
import com.virginaustralia.service.contract.loyalty_membership_management.UpdateMemberProfileException;
import org.oasis_open.docs.wss._2004._01.oasis_200401_wss_wssecurity_secext_1_0.SecurityHeaderType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class ProfileService {

	private static final String GET_PROFILE_CACHE_KEY = "GetMemberProfile";

	private GetLoyaltyMemberProfilePpt getService;
	private UpdateLoyaltyMemberProfilePpt updateService;
	private SecurityHeaderType securityHeader;
	private ProfileMapper profileMapper;

	@Autowired
	ProfileService(GetLoyaltyMemberProfilePpt getService, UpdateLoyaltyMemberProfilePpt updateService,
			ProfileMapper profileMapper, SecurityHeaderType securityHeader) {
		checkNotNull(getService, "getLoyaltyMemberProfilePpt is required");
		checkNotNull(updateService, "updateLoyaltyMemberProfilePpt is required");
		checkNotNull(securityHeader, "securityHeader is required");
		checkNotNull(profileMapper, "profileMapper is required");
		this.getService = getService;
		this.updateService = updateService;
		this.securityHeader = securityHeader;
		this.profileMapper = profileMapper;
	}

	@Cacheable(key = "#a0", value = GET_PROFILE_CACHE_KEY)
	@HystrixCommand
	public Profile getProfile(String memberId, String correlationId) {
		GetLoyaltyMemberProfileRQ rq = profileMapper.mapGetRequest(memberId);
		GetLoyaltyMemberProfileRS res;
		try {
			javax.xml.ws.Holder<TransactionResponseHeaderType> holder = new javax.xml.ws.Holder<>();
			TransactionRequestHeaderType trxHeader = HeadersConfig.trxHeader(correlationId);
			res = getService.getLoyaltyMemberProfile(rq, securityHeader, trxHeader, holder);
		} catch (GetMemberProfileException e) {
			throw new ServiceProviderException(e.getFaultInfo().getDescription(), e.getFaultInfo().getFaultCode(),
					e.getFaultInfo().getDetails());
		}

		return profileMapper.mapGetResponse(res);
	}

	@CacheEvict(value = GET_PROFILE_CACHE_KEY, key = "#a1")
	@HystrixCommand
	public ProfileUpdated updateProfile(Profile profile, String memberId, String correlationId) {
		UpdateLoyaltyMemberProfileRQ rq = profileMapper.mapUpdateRequest(profile, memberId);
		UpdateLoyaltyMemberProfileRS res;
		try {
			javax.xml.ws.Holder<TransactionResponseHeaderType> holder = new javax.xml.ws.Holder<>();
			TransactionRequestHeaderType trxHeader = HeadersConfig.trxHeader(correlationId);
			res = updateService.updateLoyaltyMemberProfile(rq, securityHeader, trxHeader, holder);
		} catch (UpdateMemberProfileException e) {
			throw new ServiceProviderException(e.getFaultInfo().getDescription(), e.getFaultInfo().getFaultCode(),
					e.getFaultInfo().getDetails());
		}

		return profileMapper.mapUpdateResponse(res);
	}
}
