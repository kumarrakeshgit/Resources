package com.velocityfrequentflyer.ms.profileapi.config;

import com.google.common.collect.Sets;
import java.util.Arrays;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.StringVendorExtension;
import springfox.documentation.service.Tag;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class Swagger {

  public static final String PROFILE_API_TAG_NAME = "Member Profile";

  @Value("${application.name}")
  private String appName;

  @Value("${application.description}")
  private String appDescription;

  @Value("${application.version}")
  private String appVersion;

  @Value("${SWAGGER_HOST:staging-api.velocityfrequentflyer.com}")
  private String host;

  private static final Tag PROFILE_API_TAG =
      new Tag(PROFILE_API_TAG_NAME, "Retrieve and Update profile details for a Velocity Member");

  @SuppressWarnings("rawtypes")
  private static final List<VendorExtension> VENDOR_EXTENSIONS =
      Arrays.asList(
          new StringVendorExtension("x-layer", "frontend"),
          new StringVendorExtension("x-technicalOwner", "TBD"),
          new StringVendorExtension("x-supportTeam", "TBD"),
          new StringVendorExtension("x-SLA", "TBD"),
          new StringVendorExtension("x-technicalDebt", ""),
          new StringVendorExtension(
              "x-technicalDesignURL",
              "https://versent.atlassian.net/wiki/spaces/VEL/pages/191037486/IPaaS+API+s"));

  private static ApiInfo API_INFO;

  @PostConstruct
  public void init() {
    API_INFO =
        new ApiInfo(
            "Velocity API",
            "Velocity API Open API Specification",
            appVersion.substring(0, appVersion.lastIndexOf(".")),
            null,
            null,
            null,
            null,
            VENDOR_EXTENSIONS);
  }

  /** @return The {@link Docket} used to describe the Swagger spec. */
  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2)
        .apiInfo(API_INFO)
        .tags(PROFILE_API_TAG)
        .useDefaultResponseMessages(false)
        .globalOperationParameters(
            Arrays.asList(
                new ParameterBuilder()
                    .name("X-JWT-ID-Token")
                    .description("JWT token")
                    .modelRef(new ModelRef("string"))
                    .parameterType("header")
                    .required(true)
                    .build()))
        .select()
        .apis(RequestHandlerSelectors.basePackage("com.velocityfrequentflyer.ms.profileapi"))
        .paths(PathSelectors.any())
        .build()
        .host(host)
        .protocols(Sets.newHashSet("https"));
  }

  @Bean
  public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() {
    return new PropertySourcesPlaceholderConfigurer();
  }
}
