package com.velocityfrequentflyer.ms.profileapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;

@JsonInclude(Include.NON_NULL)
public class ProfileUpdated {
  @ApiModelProperty(notes = "Profile Updated")
  @NotNull
  Boolean profileUpdated;

  public ProfileUpdated() {}

  public ProfileUpdated(Boolean profileUpdated) {
    super();
    this.profileUpdated = profileUpdated;
  }

  public Boolean getProfileUpdated() {
    return profileUpdated;
  }

  public void setProfileUpdated(Boolean profileUpdated) {
    this.profileUpdated = profileUpdated;
  }
}
