package com.velocityfrequentflyer.ms.profileapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import javax.validation.constraints.NotNull;

@JsonInclude(Include.NON_NULL)
public class Address {
  @ApiModelProperty(
      notes = "Address Line. Contains free form address street information",
      required = true)
  @NotNull
  private List<String> addressLine;

  @ApiModelProperty(notes = "City (e.g., Sydney), town, or postal station", required = true)
  @NotNull
  private String cityName;

  @ApiModelProperty(notes = "Post Office Code number")
  private String postalCode;

  @ApiModelProperty(notes = "County or Region Name")
  private String county;

  @ApiModelProperty(
      notes =
          "A StateCode is a 2-3 letter state code. Australian Domestic states should be provided in their\n"
              + "        typical 3 letter format. All other state/provinces should use the 2-letter ISO 3166 alpha-2 country code as defined in the\n"
              + "        standard.")
  private String stateProv;

  @ApiModelProperty(notes = "Country Code in ISO3166-1-Alpha-2 format", example = "AU")
  private String country;

  @ApiModelProperty(notes = "Address Type. HOME or BUSINESS", required = true)
  @NotNull
  private String addressType;

  @ApiModelProperty(notes = "Indicator for preffered address. 1 for preffered, 2 for others")
  private String orderSequenceNumber;

  public List<String> getAddressLine() {
    return addressLine;
  }

  public void setAddressLine(List<String> addressLine) {
    this.addressLine = addressLine;
  }

  public String getCityName() {
    return cityName;
  }

  public void setCityName(String cityName) {
    this.cityName = cityName;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getCounty() {
    return county;
  }

  public void setCounty(String county) {
    this.county = county;
  }

  public String getStateProv() {
    return stateProv;
  }

  public void setStateProv(String stateProv) {
    this.stateProv = stateProv;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getAddressType() {
    return addressType;
  }

  public void setAddressType(String addressType) {
    this.addressType = addressType;
  }

  public String getOrderSequenceNumber() {
    return orderSequenceNumber;
  }

  public void setOrderSequenceNumber(String orderSequenceNumber) {
    this.orderSequenceNumber = orderSequenceNumber;
  }

  @Override
  public String toString() {
    return "Address [addressLine="
        + addressLine
        + ", cityName="
        + cityName
        + ", postalCode="
        + postalCode
        + ", county="
        + county
        + ", stateProv="
        + stateProv
        + ", country="
        + country
        + ", addressType="
        + addressType
        + ", orderSequenceNumber="
        + orderSequenceNumber
        + "]";
  }
}
