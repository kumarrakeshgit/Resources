package com.velocityfrequentflyer.ms.profileapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;

@JsonInclude(Include.NON_NULL)
public class Email {
  @ApiModelProperty(notes = "Email")
  @NotNull
  private String value;

  @ApiModelProperty(
      notes = "Email Type. Can be 'H' for home, 'B' for business, 'E' for emergency, 'O' for other")
  @NotNull
  private String type;

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @Override
  public String toString() {
    return "Email [value=" + value + ", type=" + type + "]";
  }
}
