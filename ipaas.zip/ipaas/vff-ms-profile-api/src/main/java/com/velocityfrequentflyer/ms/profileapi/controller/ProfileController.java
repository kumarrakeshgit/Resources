package com.velocityfrequentflyer.ms.profileapi.controller;

import com.velocityfrequentflyer.ms.controller.BaseController;
import com.velocityfrequentflyer.ms.dto.ErrorResponse;
import com.velocityfrequentflyer.ms.profileapi.config.Swagger;
import com.velocityfrequentflyer.ms.profileapi.dto.Profile;
import com.velocityfrequentflyer.ms.profileapi.dto.ProfileUpdated;
import com.velocityfrequentflyer.ms.profileapi.service.ProfileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = Swagger.PROFILE_API_TAG_NAME)
@RestController
public class ProfileController extends BaseController {
  private static final Logger log = LoggerFactory.getLogger(ProfileController.class);

  @Autowired ProfileService service;

  @ApiOperation(
      value = "Get Profile Information",
      notes = "This will return profile info of the current Velocity member.",
      nickname = "getProfile")
  @ApiResponses({
    @ApiResponse(code = 401, message = "Authentication Failed", response = ErrorResponse.class),
    @ApiResponse(code = 403, message = "Permission Denied", response = ErrorResponse.class),
    @ApiResponse(code = 500, message = "Server Error", response = ErrorResponse.class)
  })
  @RequestMapping(value = "/profiles/me", method = RequestMethod.GET)
  public Profile getProfile() {
    log.debug("Get Profile");
    Profile profile = service.getProfile(getMemberId(), getCorrelationId());
    log.debug("Get Profile response: {}", profile);
    return profile;
  }

  @ApiOperation(
      value = "Update Profile Information",
      notes = "This will update profile info of the current Velocity member.",
      nickname = "updateProfile")
  @ApiResponses({
    @ApiResponse(code = 400, message = "Validation Failed", response = ErrorResponse.class),
    @ApiResponse(code = 401, message = "Authentication Failed", response = ErrorResponse.class),
    @ApiResponse(code = 403, message = "Permission Denied", response = ErrorResponse.class),
    @ApiResponse(code = 500, message = "Server Error", response = ErrorResponse.class)
  })
  @RequestMapping(value = "/profiles/me", method = RequestMethod.PATCH)
  public ProfileUpdated updateProfile(@Valid @RequestBody Profile profile) {
    log.debug("Update Profile invoked with: {}", profile);
    ProfileUpdated result = service.updateProfile(profile, getMemberId(), getCorrelationId());
    log.debug("Update Profile response: {}", result);
    return result;
  }
}
