package com.velocityfrequentflyer.ms.profileapi.mapping;

import static org.springframework.util.ObjectUtils.isEmpty;

import com.velocityfrequentflyer.ms.profileapi.dto.Address;
import com.velocityfrequentflyer.ms.profileapi.dto.Email;
import com.velocityfrequentflyer.ms.profileapi.dto.Phone;
import com.velocityfrequentflyer.ms.profileapi.dto.Profile;
import com.velocityfrequentflyer.ms.profileapi.dto.ProfileUpdated;
import com.virginaustralia.model.schema.loyalty_membership_management.AddressType;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactEmail;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactEmailType;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactTelephone;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactTelephoneType;
import com.virginaustralia.model.schema.loyalty_membership_management.Country;
import com.virginaustralia.model.schema.loyalty_membership_management.EmploymentInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.Gender;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRQ;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRS;
import com.virginaustralia.model.schema.loyalty_membership_management.MemberInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.Person;
import com.virginaustralia.model.schema.loyalty_membership_management.ProfileInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.StateProv;
import com.virginaustralia.model.schema.loyalty_membership_management.TravellerProfile;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRQ;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRS;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateMemberProfile;
import java.math.BigInteger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class ProfileMapper {
  private static final Logger log = LoggerFactory.getLogger(ProfileMapper.class);

  public UpdateLoyaltyMemberProfileRQ mapUpdateRequest(Profile profile, String memberId) {
    UpdateLoyaltyMemberProfileRQ rq = new UpdateLoyaltyMemberProfileRQ();

    UpdateMemberProfile ump = new UpdateMemberProfile();
    ump.setLoyaltyMembershipID(memberId != null ? memberId : "");

    TravellerProfile tp = new TravellerProfile();
    ump.setTravellerProfile(tp);
    MemberInformation mi = new MemberInformation();
    tp.setMemberInformation(mi);

    Person person = new Person();
    BeanUtils.copyProperties(profile, person);
    if (!isEmpty(profile.getGender())) {
      person.setGender(Gender.fromValue(profile.getGender().value()));
    }
    mi.setPerson(person);

    EmploymentInformation employment = new EmploymentInformation();
    employment.setEmployerName(profile.getEmployerName());
    employment.setEmployeeTitle(profile.getEmployeeTitle());
    mi.setEmploymentInformation(employment);

    for (Address a : profile.getAddresses()) {
      com.virginaustralia.model.schema.loyalty_membership_management.Address add =
          new com.virginaustralia.model.schema.loyalty_membership_management.Address();
      BeanUtils.copyProperties(a, add);
      if (a.getAddressLine() != null) {
        // Need to explicitly copy address lines since add doesn't have a setter
        add.getAddressLine().addAll(a.getAddressLine());
      }
      if (a.getStateProv() != null) {
        StateProv stateProv = new StateProv();
        stateProv.setStateProvCode(a.getStateProv());
        add.setStateProv(stateProv);
      }
      if (a.getCountry() != null) {
        Country country = new Country();
        country.setCountryCode(a.getCountry());
        add.setCountry(country);
      }
      add.setAddressType(AddressType.valueOf(a.getAddressType()));
      if (a.getOrderSequenceNumber() != null) {
        add.setOrderSequenceNumber(BigInteger.valueOf(Long.valueOf(a.getOrderSequenceNumber())));
      }
      mi.getAddress().add(add);
    }

    for (Phone a : profile.getPhoneNumbers()) {
      ContactTelephone p = new ContactTelephone();
      BeanUtils.copyProperties(a, p);
      p.setType(ContactTelephoneType.valueOf(a.getType()));
      p.setUnparsedTelephoneNumber(a.getPhoneNumber());
      mi.getContactTelephone().add(p);
    }

    for (Email a : profile.getEmailAddresses()) {
      ContactEmail p = new ContactEmail();
      BeanUtils.copyProperties(a, p);
      p.setType(ContactEmailType.valueOf(a.getType()));
      mi.getContactEmail().add(p);
    }

    String rd = profile.getLastMemberDetailReviewDate();
    if (rd != null) {
      try {
        ProfileInformation pi = new ProfileInformation();
        pi.setLastMemberDetailReviewDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(rd));
        tp.setProfileInformation(pi);
      } catch (DatatypeConfigurationException e) {
        log.error("Unable to set lastMemberDetailReviewDate as an XMLGregorianCalendar", e);
      }
    }

    rq.setUpdateMemberProfile(ump);

    return rq;
  }

  public ProfileUpdated mapUpdateResponse(UpdateLoyaltyMemberProfileRS res) {
    return new ProfileUpdated(res.isResponseMessage());
  }

  public GetLoyaltyMemberProfileRQ mapGetRequest(String memberId) {
    GetLoyaltyMemberProfileRQ rq = new GetLoyaltyMemberProfileRQ();

    rq.setLoyaltyMembershipID(memberId != null ? memberId : "");

    return rq;
  }

  public Profile mapGetResponse(GetLoyaltyMemberProfileRS res) {
    Profile profile = new Profile();

    MemberInformation mi = res.getMemberInformation();
    Person person = mi.getPerson();
    BeanUtils.copyProperties(person, profile);

    if (!isEmpty(person.getGender())) {
      profile.setGender(
          com.velocityfrequentflyer.ms.profileapi.dto.Gender.fromValue(person.getGender().value()));
    }

    EmploymentInformation empl = mi.getEmploymentInformation();
    if (empl != null) {
      profile.setEmployerName(empl.getEmployerName());
      profile.setEmployeeTitle(empl.getEmployeeTitle());
    }

    for (com.virginaustralia.model.schema.loyalty_membership_management.Address a :
        mi.getAddress()) {
      Address add = new Address();
      BeanUtils.copyProperties(a, add);
      add.setAddressType(a.getAddressType().toString());
      if (a.getOrderSequenceNumber() != null) {
        add.setOrderSequenceNumber(a.getOrderSequenceNumber().toString());
      }
      add.setStateProv(a.getStateProv().getStateProvCode());
      add.setCountry(a.getCountry().getCountryCode());
      profile.getAddresses().add(add);
    }

    for (ContactTelephone a : mi.getContactTelephone()) {
      Phone p = new Phone();
      BeanUtils.copyProperties(a, p);
      p.setType(a.getType().value());
      p.setPhoneNumber(a.getUnparsedTelephoneNumber());
      profile.getPhoneNumbers().add(p);
    }

    for (ContactEmail a : mi.getContactEmail()) {
      Email p = new Email();
      BeanUtils.copyProperties(a, p);
      p.setType(a.getType().value());
      profile.getEmailAddresses().add(p);
    }

    ProfileInformation profileInformation = res.getProfileInformation();
    if (profileInformation != null) {
      XMLGregorianCalendar lastMemberDetailReviewDate =
          profileInformation.getLastMemberDetailReviewDate();
      if (lastMemberDetailReviewDate != null) {
        profile.setLastMemberDetailReviewDate(lastMemberDetailReviewDate.toString());
      }
      XMLGregorianCalendar joinDate = profileInformation.getMemberSince();
      if (joinDate != null) {
        profile.setJoinDate(joinDate.toString());
      }
    }

    return profile;
  }
}
