package com.velocityfrequentflyer.ms.profileapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;

@JsonInclude(Include.NON_NULL)
public class Phone {
  @ApiModelProperty(notes = "Phone Number")
  @NotNull
  private String phoneNumber;

  @ApiModelProperty(
      notes =
          "The type of phone number for contact purposes. Values are: B = BUSINESS F = FAX H = HOME M = MOBILE O = OTHER")
  @NotNull
  private String type;

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String unparsedTelephoneNumber) {
    this.phoneNumber = unparsedTelephoneNumber;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @Override
  public String toString() {
    return "Phone [phoneNumber=" + phoneNumber + ", type=" + type + "]";
  }
}
