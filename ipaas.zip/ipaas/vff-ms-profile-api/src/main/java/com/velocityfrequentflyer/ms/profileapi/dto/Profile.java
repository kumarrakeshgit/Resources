package com.velocityfrequentflyer.ms.profileapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;

@JsonInclude(Include.NON_NULL)
public class Profile {
  @ApiModelProperty(notes = "Surname")
  private String surname;

  @ApiModelProperty(notes = "Name")
  private String givenName;

  @ApiModelProperty(notes = "Preffered Name")
  private String preferredName;

  @ApiModelProperty(notes = "Title", example = "Mr. Ms. Dr.")
  private String title;

  @ApiModelProperty(notes = "Date of birth in ISO-8601 format")
  private String dateOfBirth;

  @ApiModelProperty(notes = "Gender")
  private Gender gender;

  @ApiModelProperty(notes = "Employer Name")
  private String employerName;

  @ApiModelProperty(notes = "Employee Title")
  private String employeeTitle;

  @ApiModelProperty(notes = "Addresses")
  @Valid
  private List<Address> addresses = new ArrayList<Address>();

  @ApiModelProperty(notes = "Email Addresses")
  @Valid
  private List<Email> emailAddresses = new ArrayList<Email>();

  @ApiModelProperty(notes = "Phone Numbers")
  @Valid
  private List<Phone> phoneNumbers = new ArrayList<Phone>();

  @ApiModelProperty(notes = "Timestamp of last member detail review in ISO-8601 format")
  private String lastMemberDetailReviewDate;

  @ApiModelProperty(notes = "Join date")
  private String joinDate;

  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public String getGivenName() {
    return givenName;
  }

  public void setGivenName(String givenName) {
    this.givenName = givenName;
  }

  public String getPreferredName() {
    return preferredName;
  }

  public void setPreferredName(String preferredName) {
    this.preferredName = preferredName;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDateOfBirth() {
    return dateOfBirth;
  }

  public void setDateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public Gender getGender() {
    return gender;
  }

  public void setGender(Gender gender) {
    this.gender = gender;
  }

  public String getEmployerName() {
    return employerName;
  }

  public void setEmployerName(String employerName) {
    this.employerName = employerName;
  }

  public String getEmployeeTitle() {
    return employeeTitle;
  }

  public void setEmployeeTitle(String employeeTitle) {
    this.employeeTitle = employeeTitle;
  }

  public List<Address> getAddresses() {
    return addresses;
  }

  public void setAddresses(List<Address> addresses) {
    this.addresses = addresses;
  }

  public List<Email> getEmailAddresses() {
    return emailAddresses;
  }

  public void setEmailAddresses(List<Email> emailAddresses) {
    this.emailAddresses = emailAddresses;
  }

  public List<Phone> getPhoneNumbers() {
    return phoneNumbers;
  }

  public void setPhoneNumbers(List<Phone> phoneNumbers) {
    this.phoneNumbers = phoneNumbers;
  }

  public String getLastMemberDetailReviewDate() {
    return lastMemberDetailReviewDate;
  }

  public void setLastMemberDetailReviewDate(String lastMemberDetailReviewDate) {
    this.lastMemberDetailReviewDate = lastMemberDetailReviewDate;
  }

  public String getJoinDate() {
    return joinDate;
  }

  public void setJoinDate(String joinDate) {
    this.joinDate = joinDate;
  }

  @Override
  public String toString() {
    return "Profile [surname="
        + surname
        + ", givenName="
        + givenName
        + ", preferredName="
        + preferredName
        + ", title="
        + title
        + ", dateOfBirth="
        + dateOfBirth
        + ", gender="
        + gender
        + ", employerName="
        + employerName
        + ", employeeTitle="
        + employeeTitle
        + ", addresses="
        + addresses
        + ", emailAddresses="
        + emailAddresses
        + ", phoneNumbers="
        + phoneNumbers
        + ", lastMemberDetailReviewDate="
        + lastMemberDetailReviewDate
        + ", joinDate="
        + joinDate
        + "]";
  }
}
