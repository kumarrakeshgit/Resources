package com.velocityfrequentflyer.ms.profileapi.config;

import com.virginaustralia.service.contract.loyalty_membership_management.GetLoyaltyMemberProfilePpt;
import com.virginaustralia.service.contract.loyalty_membership_management.GetLoyaltyMemberProfileService;
import com.virginaustralia.service.contract.loyalty_membership_management.UpdateLoyaltyMemberProfilePpt;
import com.virginaustralia.service.contract.loyalty_membership_management.UpdateLoyaltyMemberProfileService;
import javax.xml.ws.BindingProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceConfig {

  @Value("${VFF_UPDATEMEMBERPROFILE_URL:}")
  private String updateUrl;

  @Value("${VFF_GETMEMBERPROFILE_URL:}")
  private String getUrl;

  @Bean
  public UpdateLoyaltyMemberProfilePpt updateLoyaltyMemberProfilePpt() {
    UpdateLoyaltyMemberProfilePpt updateService =
        new UpdateLoyaltyMemberProfileService().getUpdateLoyaltyMemberProfilePort();
    // Defaults to using service location from WSDL
    if (!updateUrl.isEmpty()) {
      ((BindingProvider) updateService)
          .getRequestContext()
          .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, updateUrl);
    }
    return updateService;
  };

  @Bean
  public GetLoyaltyMemberProfilePpt getLoyaltyMemberProfilePpt() {
    // Defaults to using service location from WSDL
    GetLoyaltyMemberProfilePpt getService =
        new GetLoyaltyMemberProfileService().getGetLoyaltyMemberProfilePort();
    if (!getUrl.isEmpty()) {
      ((BindingProvider) getService)
          .getRequestContext()
          .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, getUrl);
    }
    return getService;
  }
}
