package com.velocityfrequentflyer.ms.profileapi.dto;

public enum Gender {
  F,
  M,
  U;

  public String value() {
    return name();
  }

  public static Gender fromValue(String v) {
    return valueOf(v);
  }
}
