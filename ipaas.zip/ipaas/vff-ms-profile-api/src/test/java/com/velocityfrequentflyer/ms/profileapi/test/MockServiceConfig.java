package com.velocityfrequentflyer.ms.profileapi.test;

import static org.mockito.Mockito.mock;

import com.velocityfrequentflyer.ms.profileapi.service.ProfileService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

@Configuration
@ComponentScan(
    basePackages = {"com.velocityfrequentflyer.ms.profileapi"},
    excludeFilters =
        @ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class))
public class MockServiceConfig {

  @Bean
  ProfileService profileService() {
    return mock(ProfileService.class);
  }
}
