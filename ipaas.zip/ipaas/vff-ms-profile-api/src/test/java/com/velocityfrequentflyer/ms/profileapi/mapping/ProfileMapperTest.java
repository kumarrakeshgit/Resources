package com.velocityfrequentflyer.ms.profileapi.mapping;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.profileapi.dto.Address;
import com.velocityfrequentflyer.ms.profileapi.dto.Email;
import com.velocityfrequentflyer.ms.profileapi.dto.Gender;
import com.velocityfrequentflyer.ms.profileapi.dto.Phone;
import com.velocityfrequentflyer.ms.profileapi.dto.Profile;
import com.velocityfrequentflyer.ms.profileapi.dto.ProfileUpdated;
import com.virginaustralia.model.schema.loyalty_membership_management.AddressType;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactEmail;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactEmailType;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactTelephone;
import com.virginaustralia.model.schema.loyalty_membership_management.ContactTelephoneType;
import com.virginaustralia.model.schema.loyalty_membership_management.Country;
import com.virginaustralia.model.schema.loyalty_membership_management.EmploymentInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRQ;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRS;
import com.virginaustralia.model.schema.loyalty_membership_management.MemberInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.Person;
import com.virginaustralia.model.schema.loyalty_membership_management.ProfileInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.StateProv;
import com.virginaustralia.model.schema.loyalty_membership_management.TravellerProfile;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRQ;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRS;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import org.junit.Test;

public class ProfileMapperTest {

  private ProfileMapper mapper = new ProfileMapper();

  @Test
  public void testGetProfileRequestMapping() {
    GetLoyaltyMemberProfileRQ req = mapper.mapGetRequest("memberId");
    assertThat(req.getLoyaltyMembershipID()).isEqualTo("memberId");
  }

  @Test
  public void testGetProfileResponseMapping() throws DatatypeConfigurationException {
    GetLoyaltyMemberProfileRS res = new GetLoyaltyMemberProfileRS();
    MemberInformation mi = new MemberInformation();
    res.setMemberInformation(mi);
    Person person = new Person();
    person.setGender(com.virginaustralia.model.schema.loyalty_membership_management.Gender.M);
    person.setGivenName("Test");
    res.getMemberInformation().setPerson(person);

    EmploymentInformation employment = new EmploymentInformation();
    employment.setEmployerName("Wizard of Id");
    employment.setEmployeeTitle("Captain of heroics");
    mi.setEmploymentInformation(employment);

    com.virginaustralia.model.schema.loyalty_membership_management.Address add =
        new com.virginaustralia.model.schema.loyalty_membership_management.Address();
    add.setAddressType(AddressType.HOME);
    add.setCityName("Emerald City");
    Country country = new Country();
    country.setCountryCode("OZ");
    add.setCountry(country);
    add.setPostalCode("667");
    add.setOrderSequenceNumber(BigInteger.ONE);
    add.getAddressLine().add("123 Booger St");
    StateProv stateProv = new StateProv();
    stateProv.setStateProvCode("ASC");
    add.setStateProv(stateProv);
    mi.getAddress().add(add);

    ContactTelephone p = new ContactTelephone();
    p.setUnparsedTelephoneNumber("1234567890");
    p.setType(ContactTelephoneType.H);
    mi.getContactTelephone().add(p);

    ContactEmail email = new ContactEmail();
    email.setType(ContactEmailType.O);
    email.setValue("667@beast.com");
    mi.getContactEmail().add(email);

    ProfileInformation pi = new ProfileInformation();
    pi.setLastMemberDetailReviewDate(
        DatatypeFactory.newInstance().newXMLGregorianCalendar("2018-03-26T10:11:12+11:00"));
    TravellerProfile tp = new TravellerProfile();
    tp.setProfileInformation(pi);
    res.setProfileInformation(pi);

    Profile profile = mapper.mapGetResponse(res);

    assertThat(profile.getGivenName()).isEqualTo("Test");
    assertThat(profile.getGender()).isEqualTo(Gender.M);
    assertThat(profile.getLastMemberDetailReviewDate().toString())
        .isEqualTo("2018-03-26T10:11:12+11:00");

    assertThat(profile.getEmployeeTitle()).isEqualTo(employment.getEmployeeTitle());
    assertThat(profile.getEmployerName()).isEqualTo(employment.getEmployerName());

    assertThat(profile.getAddresses().get(0).getAddressLine().get(0))
        .isEqualTo(mi.getAddress().get(0).getAddressLine().get(0));
    assertThat(AddressType.valueOf(profile.getAddresses().get(0).getAddressType()))
        .isEqualTo(mi.getAddress().get(0).getAddressType());
    assertThat(profile.getAddresses().get(0).getCityName())
        .isEqualTo(mi.getAddress().get(0).getCityName());
    assertThat(profile.getAddresses().get(0).getPostalCode())
        .isEqualTo(mi.getAddress().get(0).getPostalCode());
    assertThat(profile.getAddresses().get(0).getStateProv())
        .isEqualTo(mi.getAddress().get(0).getStateProv().getStateProvCode());
    assertThat(profile.getAddresses().get(0).getCounty())
        .isEqualTo(mi.getAddress().get(0).getCounty());
    assertThat(profile.getAddresses().get(0).getOrderSequenceNumber())
        .isEqualTo(mi.getAddress().get(0).getOrderSequenceNumber().toString());

    assertThat(profile.getPhoneNumbers().get(0).getPhoneNumber())
        .isEqualTo(mi.getContactTelephone().get(0).getUnparsedTelephoneNumber());
    assertThat(ContactTelephoneType.fromValue(profile.getPhoneNumbers().get(0).getType()))
        .isEqualTo(mi.getContactTelephone().get(0).getType());

    assertThat(ContactEmailType.fromValue(profile.getEmailAddresses().get(0).getType()))
        .isEqualTo(mi.getContactEmail().get(0).getType());
    assertThat(profile.getEmailAddresses().get(0).getValue())
        .isEqualTo(mi.getContactEmail().get(0).getValue());
  }

  @Test
  public void testGetProfileResponseMapping_NullGender() throws DatatypeConfigurationException {
    GetLoyaltyMemberProfileRS res = new GetLoyaltyMemberProfileRS();
    MemberInformation mi = new MemberInformation();
    res.setMemberInformation(mi);
    Person person = new Person();
    person.setGivenName("Test");
    res.getMemberInformation().setPerson(person);

    ProfileInformation pi = new ProfileInformation();
    pi.setLastMemberDetailReviewDate(
        DatatypeFactory.newInstance().newXMLGregorianCalendar("2018-03-26T10:11:12+11:00"));
    TravellerProfile tp = new TravellerProfile();
    tp.setProfileInformation(pi);
    res.setProfileInformation(pi);

    Profile profile = mapper.mapGetResponse(res);

    assertThat(profile.getGivenName()).isEqualTo("Test");
    assertThat(profile.getGender()).isNull();
    assertThat(profile.getLastMemberDetailReviewDate().toString())
        .isEqualTo("2018-03-26T10:11:12+11:00");
  }

  @Test
  public void testUpdateProfileRequestMapping() {
    Profile profile = new Profile();
    profile.setGender(Gender.F);
    profile.setSurname("Prokhor");

    List<Phone> phoneNumbers = new ArrayList<>();
    Phone phone = new Phone();
    phone.setPhoneNumber("1231231231");
    phone.setType("M");
    phoneNumbers.add(phone);
    profile.setPhoneNumbers(phoneNumbers);

    List<Email> emails = new ArrayList<Email>();
    Email email = new Email();
    email.setType("O");
    email.setValue("abc@test.com");
    emails.add(email);
    profile.setEmailAddresses(emails);

    List<Address> addresses = new ArrayList<>();
    Address address = new Address();
    address.setAddressType("HOME");
    address.setCityName("Emerald City");
    address.setCountry("Oz");
    address.setPostalCode("911");
    address.setStateProv("Kansas");
    String[] addressLines = {"123 Seasme Street"};
    address.setAddressLine(Arrays.asList(addressLines));
    addresses.add(address);
    profile.setAddresses(addresses);
    profile.setLastMemberDetailReviewDate("2018-03-26T10:11:12+11:00");

    profile.setEmployeeTitle("Captain of comedic relief");
    profile.setEmployerName("Wizard of OZ");

    UpdateLoyaltyMemberProfileRQ req = mapper.mapUpdateRequest(profile, "memberId");
    assertThat(req.getUpdateMemberProfile().getLoyaltyMembershipID()).isEqualTo("memberId");
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getPerson()
                .getGender()
                .value())
        .isEqualTo("F");
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getPerson()
                .getSurname())
        .isEqualTo("Prokhor");
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getProfileInformation()
                .getLastMemberDetailReviewDate()
                .toString())
        .isEqualTo("2018-03-26T10:11:12+11:00");
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .size())
        .isEqualTo(1);
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .get(0)
                .getAddressLine())
        .isEqualTo(profile.getAddresses().get(0).getAddressLine());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .get(0)
                .getAddressType())
        .isEqualTo(AddressType.fromValue(profile.getAddresses().get(0).getAddressType()));
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .get(0)
                .getCountry()
                .getCountryCode())
        .isEqualTo(profile.getAddresses().get(0).getCountry());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .get(0)
                .getCityName())
        .isEqualTo(profile.getAddresses().get(0).getCityName());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .get(0)
                .getPostalCode())
        .isEqualTo(profile.getAddresses().get(0).getPostalCode());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getAddress()
                .get(0)
                .getStateProv()
                .getStateProvCode())
        .isEqualTo(profile.getAddresses().get(0).getStateProv());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getContactTelephone()
                .get(0)
                .getUnparsedTelephoneNumber())
        .isEqualTo(profile.getPhoneNumbers().get(0).getPhoneNumber());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getContactEmail()
                .get(0)
                .getType())
        .isEqualTo(ContactEmailType.fromValue(profile.getEmailAddresses().get(0).getType()));
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getEmploymentInformation()
                .getEmployeeTitle())
        .isEqualTo(profile.getEmployeeTitle());
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getEmploymentInformation()
                .getEmployerName())
        .isEqualTo(profile.getEmployerName());
  }

  @Test
  public void testUpdateProfileRequestMapping_Gender() {
    Profile profile = new Profile();
    profile.setGender(null);
    profile.setSurname("Prokhor");
    profile.setLastMemberDetailReviewDate("2018-03-26T10:11:12+11:00");
    UpdateLoyaltyMemberProfileRQ req = mapper.mapUpdateRequest(profile, "memberId");
    assertThat(req.getUpdateMemberProfile().getLoyaltyMembershipID()).isEqualTo("memberId");
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getPerson()
                .getGender())
        .isNull();
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getMemberInformation()
                .getPerson()
                .getSurname())
        .isEqualTo("Prokhor");
    assertThat(
            req.getUpdateMemberProfile()
                .getTravellerProfile()
                .getProfileInformation()
                .getLastMemberDetailReviewDate()
                .toString())
        .isEqualTo("2018-03-26T10:11:12+11:00");
  }

  @Test
  public void testUpdateProfileResponseMapping() {
    UpdateLoyaltyMemberProfileRS res = new UpdateLoyaltyMemberProfileRS();
    res.setResponseMessage(true);
    ProfileUpdated req = mapper.mapUpdateResponse(res);
    assertThat(req.getProfileUpdated()).isEqualTo(true);
  }
}
