package com.velocityfrequentflyer.ms.profileapi.swagger;

import com.velocityfrequentflyer.ms.MsApplication;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {MsApplication.class},
    webEnvironment = WebEnvironment.RANDOM_PORT)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProduceSwaggerTest {

  @Autowired private TestRestTemplate restTemplate;

  @Test
  public void createSpringfoxSwaggerJson() throws Exception {
    ResponseEntity<String> response = this.restTemplate.getForEntity("/v2/api-docs", String.class);

    String swaggerJson = response.getBody().toString();
    Files.createDirectories(Paths.get("target/swagger"));
    try (BufferedWriter writer =
        Files.newBufferedWriter(
            Paths.get("target/swagger", "swagger.json"), StandardCharsets.UTF_8)) {
      writer.write(swaggerJson);
    }
  }
}
