package com.velocityfrequentflyer.ms.profileapi.dto.validation;

import static org.junit.Assert.assertEquals;

import com.velocityfrequentflyer.ms.profileapi.dto.Phone;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PhoneValidationTest {

  private static Validator validator;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    validator = validatorFactory.getValidator();
  }

  private Phone phone;

  @Before
  public void setUp() throws Exception {
    phone = new Phone();
    phone.setType("H");
  }

  @Test
  public void testNormalNumber() {
    phone.setPhoneNumber("0412345678");
    Set<ConstraintViolation<Phone>> constraintViolations = validator.validate(phone);
    assertEquals(0, constraintViolations.size());
  }

  @Test
  // IP-528: empty number allowed for removal of the number of this type from profile
  public void testEmptyNumber() {
    phone.setPhoneNumber("");
    Set<ConstraintViolation<Phone>> constraintViolations = validator.validate(phone);
    assertEquals(0, constraintViolations.size());
  }
}
