package com.velocityfrequentflyer.ms.profileapi.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import com.velocityfrequentflyer.ms.MsApplication;
import com.velocityfrequentflyer.ms.profileapi.dto.Address;
import com.velocityfrequentflyer.ms.profileapi.dto.Email;
import com.velocityfrequentflyer.ms.profileapi.dto.Gender;
import com.velocityfrequentflyer.ms.profileapi.dto.Phone;
import com.velocityfrequentflyer.ms.profileapi.dto.Profile;
import com.velocityfrequentflyer.ms.profileapi.dto.ProfileUpdated;
import com.velocityfrequentflyer.ms.profileapi.service.ProfileService;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {MsApplication.class},
    webEnvironment = WebEnvironment.RANDOM_PORT)
@TestPropertySource(
    properties = {"jwt-auth.test-member-id = test"},
    locations = {"classpath:config/application.yml"})
public class ProfileControllerITTest {

  @Autowired private TestRestTemplate restTemplate;
  @Autowired private ProfileService service;

  @Test
  public void testGetProfile() {
    when(service.getProfile(anyString(), anyString())).thenReturn(createMockProfile());
    ResponseEntity<Profile> entity =
        this.restTemplate.getForEntity("/v1/profiles/me", Profile.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.OK);
    assertThat(entity.getBody().getGivenName()).isEqualTo("Misha");
    assertThat(entity.getBody().getAddresses().get(0).getCountry()).isEqualTo("AU");
    assertThat(entity.getBody().getAddresses().get(0).getStateProv()).isEqualTo("NSW");
  }

  @Test
  public void testUpdateProfile() {
    Profile profile = createMockProfile();

    ProfileUpdated profileUpdate = new ProfileUpdated();
    profileUpdate.setProfileUpdated(true);

    when(service.updateProfile(anyObject(), anyString(), anyString())).thenReturn(profileUpdate);
    ProfileUpdated entity =
        this.restTemplate.patchForObject("/v1/profiles/me", profile, ProfileUpdated.class);
    assertThat(entity.getProfileUpdated()).isEqualTo(true);
  }

  private Profile createMockProfile() {
    Profile profile = new Profile();
    profile.setGender(Gender.M);
    profile.setDateOfBirth("10/10/2000");
    profile.setGivenName("Misha");
    profile.setSurname("Zhopa");

    Address a = new Address();
    a.setAddressType("HOME");
    List<String> lines = new ArrayList<String>();
    lines.add("10 adfa str.");
    a.setAddressLine(lines);
    a.setCountry("AU");
    a.setCityName("Sydney");
    a.setPostalCode("2224");
    a.setStateProv("NSW");
    List<Address> list = new ArrayList<Address>();
    list.add(a);
    profile.setAddresses(list);

    Phone p = new Phone();
    p.setType("H");
    p.setPhoneNumber("041999999999");
    List<Phone> plist = new ArrayList<Phone>();
    plist.add(p);
    profile.setPhoneNumbers(plist);

    Email e = new Email();
    e.setValue("adad@email.com");
    e.setType("H");
    List<Email> elist = new ArrayList<Email>();
    elist.add(e);
    profile.setEmailAddresses(elist);
    return profile;
  }
}
