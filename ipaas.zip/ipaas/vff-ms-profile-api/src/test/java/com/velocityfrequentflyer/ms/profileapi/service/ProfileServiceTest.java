package com.velocityfrequentflyer.ms.profileapi.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.velocityfrequentflyer.ms.exception.ServiceProviderException;
import com.velocityfrequentflyer.ms.profileapi.dto.Address;
import com.velocityfrequentflyer.ms.profileapi.dto.Email;
import com.velocityfrequentflyer.ms.profileapi.dto.Phone;
import com.velocityfrequentflyer.ms.profileapi.dto.Profile;
import com.velocityfrequentflyer.ms.profileapi.dto.ProfileUpdated;
import com.velocityfrequentflyer.ms.profileapi.mapping.ProfileMapper;
import com.virginaustralia.model.schema.loyalty_membership_management.Gender;
import com.virginaustralia.model.schema.loyalty_membership_management.GetLoyaltyMemberProfileRS;
import com.virginaustralia.model.schema.loyalty_membership_management.MemberInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.Person;
import com.virginaustralia.model.schema.loyalty_membership_management.ProfileInformation;
import com.virginaustralia.model.schema.loyalty_membership_management.TravellerProfile;
import com.virginaustralia.model.schema.loyalty_membership_management.UpdateLoyaltyMemberProfileRS;
import com.virginaustralia.service.contract.loyalty_membership_management.GetLoyaltyMemberProfilePpt;
import com.virginaustralia.service.contract.loyalty_membership_management.GetMemberProfileException;
import com.virginaustralia.service.contract.loyalty_membership_management.UpdateLoyaltyMemberProfilePpt;
import com.virginaustralia.service.contract.loyalty_membership_management.UpdateMemberProfileException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.oasis_open.docs.wss._2004._01.oasis_200401_wss_wssecurity_secext_1_0.SecurityHeaderType;

@RunWith(MockitoJUnitRunner.class)
public class ProfileServiceTest {
  private ProfileService service;
  private GetLoyaltyMemberProfilePpt getService = mock(GetLoyaltyMemberProfilePpt.class);
  private UpdateLoyaltyMemberProfilePpt updateService = mock(UpdateLoyaltyMemberProfilePpt.class);
  private SecurityHeaderType securityHeader = mock(SecurityHeaderType.class);
  private ProfileMapper profileMapper = new ProfileMapper();
  private GetLoyaltyMemberProfileRS getLoyaltyMemberProfileRS;

  @Before
  public void setUp() {
    service = new ProfileService(getService, updateService, profileMapper, securityHeader);
  }

  @Test
  public void getProfileTest() throws Exception {
    getLoyaltyMemberProfileRS = getMockSOAProfile();
    when(getService.getLoyaltyMemberProfile(anyObject(), anyObject(), anyObject(), anyObject()))
        .thenReturn(getLoyaltyMemberProfileRS);
    Profile profile = service.getProfile("anc", "123");
    assertThat(profile.getGender()).isEqualTo(com.velocityfrequentflyer.ms.profileapi.dto.Gender.M);
    assertThat(profile.getGivenName())
        .isEqualTo(getLoyaltyMemberProfileRS.getMemberInformation().getPerson().getGivenName());
    assertThat(profile.getAddresses().size()).isEqualTo(0);
  }

  @Test(expected = ServiceProviderException.class)
  public void getProfileExeceptionTest()
      throws GetMemberProfileException, DatatypeConfigurationException {
    com.virginaustralia.model.schema.utility.FaultType ft =
        new com.virginaustralia.model.schema.utility.FaultType();
    ft.setDescription("desc");
    ft.setDetails("details");
    ft.setFaultCode("faultCode");
    ft.setFaultType("faultType");
    ft.setSource("Tomato");
    ft.setDateTimeStamp(
        DatatypeFactory.newInstance().newXMLGregorianCalendar("2018-03-26T10:11:12+11:00"));
    GetMemberProfileException ex = new GetMemberProfileException("message", ft);
    when(getService.getLoyaltyMemberProfile(anyObject(), anyObject(), anyObject(), anyObject()))
        .thenThrow(ex);
    service.getProfile("anc", "123");
  }

  @Test
  public void updateProfileTest() throws Exception {
    UpdateLoyaltyMemberProfileRS response = new UpdateLoyaltyMemberProfileRS();
    response.setResponseMessage(true);
    when(updateService.updateLoyaltyMemberProfile(
            anyObject(), anyObject(), anyObject(), anyObject()))
        .thenReturn(response);

    Profile profile = getMockProfile();
    ProfileUpdated profileUD = service.updateProfile(profile, "ABC", "ABC");
    assertThat(profileUD.getProfileUpdated()).isTrue();
  }

  @Test(expected = ServiceProviderException.class)
  public void updateProfileExceptionTest() throws Exception {
    com.virginaustralia.model.schema.utility.FaultType ft =
        new com.virginaustralia.model.schema.utility.FaultType();
    ft.setDescription("desc");
    ft.setDetails("details");
    ft.setFaultCode("faultCode");
    ft.setFaultType("faultType");
    ft.setSource("Tomato");
    ft.setDateTimeStamp(
        DatatypeFactory.newInstance().newXMLGregorianCalendar("2018-03-26T10:11:12+11:00"));
    UpdateMemberProfileException ex = new UpdateMemberProfileException("message", ft);
    when(updateService.updateLoyaltyMemberProfile(
            anyObject(), anyObject(), anyObject(), anyObject()))
        .thenThrow(ex);
    service.updateProfile(getMockProfile(), "memid", "cid");
  }

  private GetLoyaltyMemberProfileRS getMockSOAProfile() throws DatatypeConfigurationException {
    GetLoyaltyMemberProfileRS res = new GetLoyaltyMemberProfileRS();
    MemberInformation mi = new MemberInformation();
    res.setMemberInformation(mi);
    Person person = new Person();
    person.setGender(Gender.M);
    person.setGivenName("Test");
    res.getMemberInformation().setPerson(person);

    ProfileInformation pi = new ProfileInformation();
    pi.setLastMemberDetailReviewDate(
        DatatypeFactory.newInstance().newXMLGregorianCalendar("2018-03-26T10:11:12+11:00"));
    TravellerProfile tp = new TravellerProfile();
    tp.setProfileInformation(pi);
    res.setProfileInformation(pi);
    return res;
  }

  private Profile getMockProfile() {
    Profile profile = new Profile();
    profile.setGender(com.velocityfrequentflyer.ms.profileapi.dto.Gender.F);
    profile.setSurname("Prokhor");
    List<Phone> phoneNumbers = new ArrayList<>();
    Phone phone = new Phone();
    phone.setPhoneNumber("1231231231");
    phone.setType("M");
    phoneNumbers.add(phone);
    profile.setPhoneNumbers(phoneNumbers);
    List<Email> emails = new ArrayList<Email>();
    Email email = new Email();
    email.setType("O");
    email.setValue("abc@test.com");
    emails.add(email);
    profile.setEmailAddresses(emails);
    List<Address> addresses = new ArrayList<>();
    Address address = new Address();
    address.setAddressType("HOME");
    String[] addressLines = {"123 Seasme Street"};
    address.setAddressLine(Arrays.asList(addressLines));
    addresses.add(address);
    profile.setAddresses(addresses);
    profile.setLastMemberDetailReviewDate("2018-03-26T10:11:12+11:00");
    return profile;
  }
}
