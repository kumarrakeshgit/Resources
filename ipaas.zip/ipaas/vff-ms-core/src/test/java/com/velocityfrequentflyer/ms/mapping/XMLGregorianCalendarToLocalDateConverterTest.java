package com.velocityfrequentflyer.ms.mapping;

import static org.assertj.core.api.Assertions.assertThat;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import java.time.LocalDate;
import javax.xml.datatype.XMLGregorianCalendar;
import ma.glasnost.orika.Converter;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.metadata.TypeFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

/** @author Deniss Sudak */
@RunWith(MockitoJUnitRunner.class)
public class XMLGregorianCalendarToLocalDateConverterTest {

  private Converter<XMLGregorianCalendar, LocalDate> converter;

  @Mock private MappingContext mappingContext;

  @Before
  public void setup() {
    converter = new XMLGregorianCalendarToLocalDateConverter();
  }

  /**
   * It should convert {@link XMLGregorianCalendar} into {@link LocalDate}. Please note that XSD
   * Date month field starts with 1 (JANUARY).
   */
  @Test
  public void testConvert() {
    XMLGregorianCalendar date = XMLGregorianCalendarImpl.createDate(2015, 1, 15, 10 * 60);

    LocalDate result =
        converter.convert(date, TypeFactory.valueOf(LocalDate.class), mappingContext);

    assertThat(result).isEqualTo(LocalDate.of(2015, 1, 15));
  }
}
