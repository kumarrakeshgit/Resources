package com.velocityfrequentflyer.ms.cache;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.junit.Test;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;

/** @author Deniss Sudak */
public class SoaJackson2JsonRedisSerializerTest {

  private RedisSerializer<Object> serializer = new SoaJackson2JsonRedisSerializer();

  /**
   * It should serialize and deserialize type with property of type {@link XMLGregorianCalendar}
   * This is the case that {@link GenericJackson2JsonRedisSerializer} couldn't cope with and the
   * reason why {@link SoaJackson2JsonRedisSerializer} was created
   */
  @Test
  public void testSerializeAndDeserializeTypeWithXMLGregorianCalendar()
      throws DatatypeConfigurationException {

    SomeType type = new SomeType();
    DatatypeFactory dtf = DatatypeFactory.newInstance();
    XMLGregorianCalendar activityDate =
        dtf.newXMLGregorianCalendar(1974, 10, 10, 18, 15, 17, 123, 0);
    type.setActivityDate(activityDate);
    type.setSomeDate(LocalDate.now());

    Object deserialized = serializer.deserialize(serializer.serialize(type));
    assertThat(deserialized).isNotNull().isInstanceOf(SomeType.class);
    assertThat(((SomeType) deserialized).getActivityDate()).isEqualTo(activityDate);
  }

  public static class SomeType {

    private XMLGregorianCalendar activityDate;
    private LocalDate someDate;

    public XMLGregorianCalendar getActivityDate() {
      return activityDate;
    }

    public void setActivityDate(XMLGregorianCalendar value) {
      this.activityDate = value;
    }

    public LocalDate getSomeDate() {
      return someDate;
    }

    public void setSomeDate(LocalDate someDate) {
      this.someDate = someDate;
    }
  }
}
