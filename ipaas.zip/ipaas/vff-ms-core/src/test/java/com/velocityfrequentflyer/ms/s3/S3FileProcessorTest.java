package com.velocityfrequentflyer.ms.s3;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CopyObjectResult;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import java.io.File;
import java.io.IOException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class S3FileProcessorTest {

  private AmazonS3 amazonS3 = mock(AmazonS3.class);
  private S3FileProcessor s3FileProcessor;

  @Rule public TemporaryFolder folder = new TemporaryFolder();

  @Before
  public void setUp() throws Exception {
    s3FileProcessor = new S3FileProcessor(amazonS3);
    when(amazonS3.getObject(any(GetObjectRequest.class), any(File.class)))
        .thenReturn(new ObjectMetadata());
  }

  @Test
  public void downloadFileFromS3() throws IOException {
    File fileFromS3 = s3FileProcessor.downloadFileFromS3("testBucket", "testFile.txt");
    verify(amazonS3, times(1)).getObject(any(GetObjectRequest.class), any(File.class));
    assertThat(fileFromS3).exists().hasExtension("tmp");
  }

  @Test
  public void downloadFileFromS3WithFileExtention() throws IOException {
    File fileFromS3 = s3FileProcessor.downloadFileFromS3("testBucket", "testFile.txt", ".log");
    verify(amazonS3, times(1)).getObject(any(GetObjectRequest.class), any(File.class));
    assertThat(fileFromS3).exists().hasExtension("log");
  }

  @Test
  public void moveFileWithinBucket() {
    reset(amazonS3);
    when(amazonS3.copyObject(anyString(), anyString(), anyString(), anyString()))
        .thenReturn(new CopyObjectResult());
    Boolean result = s3FileProcessor.moveFileWithinBucket("testBucket", "srcFile", "destFile");
    assertThat(result).isTrue();
    verify(amazonS3, times(1)).copyObject("testBucket", "srcFile", "testBucket", "destFile");
  }

  @Test
  public void moveFileBetweenBuckets() {
    reset(amazonS3);
    when(amazonS3.copyObject(anyString(), anyString(), anyString(), anyString()))
        .thenReturn(new CopyObjectResult());
    Boolean result =
        s3FileProcessor.moveFileBetweenBuckets("srcBucket", "srcFile", "destBucket", "destFile");
    assertThat(result).isTrue();
    verify(amazonS3, times(1)).copyObject("srcBucket", "srcFile", "destBucket", "destFile");
  }

  @Test
  public void moveFileBetweenBucket_WithException() {
    reset(amazonS3);
    when(amazonS3.copyObject(anyString(), anyString(), anyString(), anyString()))
        .thenThrow(new AmazonServiceException("test"));
    Boolean result =
        s3FileProcessor.moveFileBetweenBuckets("srcBucket", "srcFile", "destBucket", "destFile");
    assertThat(result).isFalse();
    verify(amazonS3, times(1)).copyObject("srcBucket", "srcFile", "destBucket", "destFile");
  }
}
