package com.velocityfrequentflyer.ms.dto;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TierInfoTest {
  @Test
  public void testGettingCorrectTierCode() {
    TierInfo tierInfo = new TierInfo();
    tierInfo.setTierLevel("G");
    tierInfo.setSubTierLevel("C");
    assertEquals("CG", tierInfo.retrieveTierCode());
  }

  @Test
  public void testGetTierWhenEmptyTier() {
    TierInfo tierInfo = new TierInfo();
    assertEquals("", tierInfo.retrieveTierCode());
  }

  @Test
  public void testGetTierWhenOnlyTier() {
    TierInfo tierInfo = new TierInfo();
    tierInfo.setTierLevel("G");
    assertEquals("G", tierInfo.retrieveTierCode());
  }

  @Test
  public void testGetTierWhenOnlySubTier() {
    TierInfo tierInfo = new TierInfo();
    tierInfo.setSubTierLevel("C");
    assertEquals("C", tierInfo.retrieveTierCode());
  }

  @Test
  public void testGetCapitalizeSubTier() {
    TierInfo tierInfo = new TierInfo();
    tierInfo.setTierLevel("g");
    tierInfo.setSubTierLevel("c");
    assertEquals("CG", tierInfo.retrieveTierCode());
  }
}
