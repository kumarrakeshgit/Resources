package com.velocityfrequentflyer.ms.dto.subtier;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.velocityfrequentflyer.ms.subtier.dto.SubTier;
import javax.validation.Validation;
import javax.validation.Validator;
import org.junit.Before;
import org.junit.Test;

public class SubTierTest {
  private Validator validator;

  @Before
  public void setup() {
    validator = Validation.buildDefaultValidatorFactory().getValidator();
  }

  @Test
  public void testValidData() {
    SubTier subtier =
        new SubTier(
            "SR",
            "Red",
            "Red",
            "Standard Red",
            12,
            12,
            "SR",
            0,
            0,
            "N/A",
            "SS",
            245,
            2,
            "No rules");
    assertTrue(validator.validate(subtier).isEmpty());
  }

  @Test
  public void validateSubTierLevelSet() {
    SubTier subtier =
        new SubTier(
            "SR",
            "Red",
            "Red",
            "Standard Red",
            12,
            12,
            "SR",
            0,
            0,
            "N/A",
            "SS",
            245,
            2,
            "No rules");
    assertEquals("S", subtier.getSubTierLevel());
    subtier = new SubTier("CS");
    assertEquals("C", subtier.getSubTierLevel());
    subtier.setTierCode("EP");
    assertEquals("E", subtier.getSubTierLevel());
  }

  @Test
  public void validateTierLevelSet() {
    SubTier subtier =
        new SubTier(
            "SR",
            "Red",
            "Red",
            "Standard Red",
            12,
            12,
            "SR",
            0,
            0,
            "N/A",
            "SS",
            245,
            2,
            "No rules");
    assertEquals("R", subtier.getTierLevel());
    subtier = new SubTier("CS");
    assertEquals("S", subtier.getTierLevel());
    subtier.setTierCode("EP");
    assertEquals("P", subtier.getTierLevel());
  }

  @Test
  public void validateIsDowngradable() {
    SubTier subtier =
        new SubTier(
            "SS",
            "Siver",
            "Silver",
            "Standard Silver",
            12,
            12,
            "SS",
            200,
            2,
            "SR",
            "SG",
            490,
            4,
            "");
    assertTrue(subtier.isDowngradable());
  }

  @Test
  public void validateIsNotDowngradable() {
    SubTier subtier =
        new SubTier(
            "SR",
            "Red",
            "Red",
            "Standard Red",
            12,
            12,
            "SR",
            0,
            0,
            "N/A",
            "SS",
            245,
            2,
            "No rules");
    assertFalse(subtier.isDowngradable());
  }

  @Test
  public void validateIsUpgradable() {
    SubTier subtier =
        new SubTier(
            "SS",
            "Siver",
            "Silver",
            "Standard Silver",
            12,
            12,
            "SS",
            200,
            2,
            "SR",
            "SG",
            490,
            4,
            "");
    assertTrue(subtier.isUpgradable());
  }

  @Test
  public void validateIsNotUpgradable() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    assertFalse(subtier.isUpgradable());
  }

  @Test
  public void validateValidTierInput() {
    String[] valid = {"CG", "BB", "EG"};
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    for (String tierCode : valid) {
      subtier.setTierCode(tierCode);
      assertTrue(validator.validate(subtier).isEmpty());
    }
  }

  @Test
  public void validateInvalidTierInput() throws Exception {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    try {
      subtier.setTierCode("abc");
      throw new Exception("Should not have validated an invalid tier code");
    } catch (IllegalArgumentException iae) {
      assertEquals(
          "abc is invalid. Tier Code is only a 2 character code comprising of the subtier level and the tier level",
          iae.getMessage());
    }
  }

  @Test
  public void validateInvalidTierInputSingleChar() throws Exception {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    try {
      subtier.setTierCode("b");
      throw new Exception("Should not have validated an invalid tier code");
    } catch (IllegalArgumentException iae) {
      assertEquals(
          "b is invalid. Tier Code is only a 2 character code comprising of the subtier level and the tier level",
          iae.getMessage());
    }
  }

  @Test
  public void validateNATierCodes() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    subtier.setMaintainTierCode("N/A");
    assertTrue(validator.validate(subtier).isEmpty());
    subtier.setDowngradeTierCode("N/A");
    assertTrue(validator.validate(subtier).isEmpty());
    subtier.setUpgradeTierCode("N/A");
    assertTrue(validator.validate(subtier).isEmpty());
  }

  @Test
  public void validateInvalidMaintenanceTierCode() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    subtier.setMaintainTierCode("abc");
    assertFalse(validator.validate(subtier).isEmpty());
  }

  @Test
  public void validateInvalidMaintenanceTierCodeSingleChar() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    subtier.setMaintainTierCode("b");
    assertFalse(validator.validate(subtier).isEmpty());
  }

  @Test
  public void validateInvalidDowngradeTierCode() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    subtier.setDowngradeTierCode("abc");
    assertFalse(validator.validate(subtier).isEmpty());
  }

  @Test
  public void validateInvalidDowngradeTierCodeSingleChar() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    subtier.setDowngradeTierCode("b");
    assertFalse(validator.validate(subtier).isEmpty());
  }

  @Test
  public void validateInvalidUpgradeTierCode() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SP",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    subtier.setUpgradeTierCode("abc");
    assertFalse(validator.validate(subtier).isEmpty());
  }

  @Test
  public void capitalizeTierCode() {
    SubTier subtier = new SubTier("ac");
    assertEquals(subtier.getTierCode(), "AC");
  }

  @Test
  public void capitalizeMaintainTierCode() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "ss",
            400,
            4,
            "SG",
            "N/A",
            0,
            0,
            "");
    assertEquals(subtier.getMaintainTierCode(), "SS");
  }

  @Test
  public void capitalizeUpgradeTierCode() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SS",
            400,
            4,
            "SG",
            "dd",
            0,
            0,
            "");
    assertEquals(subtier.getUpgradeTierCode(), "DD");
  }

  @Test
  public void capitalizeDowngradeTierCode() {
    SubTier subtier =
        new SubTier(
            "SP",
            "Platinum",
            "Platinum",
            "Standard Gold",
            12,
            12,
            "SS",
            400,
            4,
            "dd",
            "SD",
            0,
            0,
            "");
    assertEquals(subtier.getDowngradeTierCode(), "DD");
  }
}
