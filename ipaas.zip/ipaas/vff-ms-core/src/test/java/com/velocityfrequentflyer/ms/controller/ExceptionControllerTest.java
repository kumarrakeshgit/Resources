package com.velocityfrequentflyer.ms.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.MsApplication;
import com.velocityfrequentflyer.ms.dto.ErrorResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {MsApplication.class},
    webEnvironment = WebEnvironment.RANDOM_PORT)
public class ExceptionControllerTest {

  @Autowired private TestRestTemplate restTemplate;

  @Test
  public void testValidationException() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/validation", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    assertThat(entity.getBody().getTitle()).isEqualTo("Validation error");
    assertThat(entity.getBody().getTitle()).isEqualTo(entity.getBody().getMessage());
    assertThat(entity.getBody().getStatus()).isEqualTo(400);
    assertThat(entity.getBody().getDetail()).isEqualTo("Incorrect name");
    assertThat(entity.getBody().getDetail()).isEqualTo(entity.getBody().getDescription());
    assertThat(entity.getBody().getInstance()).isEqualTo("/v1/validation");
    assertThat(entity.getBody().getMid()).isEqualTo("abcdef");
    assertThat(entity.getBody().getType()).isEqualTo("loyalty:InvalidRequestError");
  }

  @Test
  public void testMissingContextException() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/missing-context", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    assertThat(entity.getBody().getTitle()).isEqualTo("Missing Context");
    assertThat(entity.getBody().getStatus()).isEqualTo(400);
    assertThat(entity.getBody().getDetail()).isEqualTo("No Request Context set");
    assertThat(entity.getBody().getInstance()).isEqualTo("/v1/missing-context");
    assertThat(entity.getBody().getMid()).isEqualTo("abcdef");
    assertThat(entity.getBody().getType()).isEqualTo("loyalty:InvalidRequestError");
  }

  @Test
  public void testServiceException() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/service", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    assertThat(entity.getBody().getTitle()).isEqualTo("Loyalty Membership profile already exists.");
    assertThat(entity.getBody().getStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
    assertThat(entity.getBody().getDetail())
        .isEqualTo("Velocity membership profile already exists.");
    assertThat(entity.getBody().getInstance()).isEqualTo("/v1/service");
    assertThat(entity.getBody().getMid()).isEqualTo("abcdef");
    assertThat(entity.getBody().getType())
        .isEqualTo("loyalty:LoyaltyMembershipProfileAlreadyExists");
  }

  @Test
  public void testServiceException_WithEncoding() {
    ResponseEntity<String> entityRaw = this.restTemplate.getForEntity("/v1/service2", String.class);

    System.out.println(entityRaw.getBody());

    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/service2", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    assertThat(entity.getBody().getTitle()).isEqualTo("Account doesn't exists");
    assertThat(entity.getBody().getStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
    assertThat(entity.getBody().getDetail()).isEqualTo("Customer account doesn't exist.");
    assertThat(entity.getBody().getInstance()).isEqualTo("/v1/service2");
    assertThat(entity.getBody().getMid()).isEqualTo("abcdef");
    assertThat(entity.getBody().getType()).isEqualTo("loyalty:AccountDoesntExists");
  }

  @Test
  public void testHystrixException() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/hystrix", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @Test
  public void testAuthException() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/auth", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
  }

  @Test
  public void testNotFoundException() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/v1/notfound", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
  }
}
