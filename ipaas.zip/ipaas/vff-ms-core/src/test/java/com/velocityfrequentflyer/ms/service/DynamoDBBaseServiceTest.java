package com.velocityfrequentflyer.ms.service;

import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class DynamoDBBaseServiceTest {

  private DynamoDBBaseService service = new DynamoDBBaseService("tttess");

  @Test
  public void testBaseDBService() {
    ReflectionTestUtils.setField(
        service, "dynamoEndpoint", "https://dynamodb.ap-southeast-2.amazonaws.com");
    service.init();
  }
}
