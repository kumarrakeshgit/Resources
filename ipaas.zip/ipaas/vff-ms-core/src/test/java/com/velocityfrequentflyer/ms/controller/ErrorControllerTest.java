package com.velocityfrequentflyer.ms.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.MsApplication;
import com.velocityfrequentflyer.ms.dto.ErrorResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {MsApplication.class},
    webEnvironment = WebEnvironment.RANDOM_PORT)
public class ErrorControllerTest {

  @Autowired private TestRestTemplate restTemplate;

  @Test
  public void testWrongPathResponse() {
    ResponseEntity<ErrorResponse> entity =
        this.restTemplate.getForEntity("/sdfsdfsfd", ErrorResponse.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    assertThat(entity.getBody().getStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());
    assertThat(entity.getBody().getTitle()).isEqualTo("Path not found");
  }
}
