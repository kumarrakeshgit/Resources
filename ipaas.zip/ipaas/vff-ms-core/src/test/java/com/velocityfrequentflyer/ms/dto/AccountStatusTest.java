package com.velocityfrequentflyer.ms.dto;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountStatusTest {

  @Test
  public void testAccessor() {}
}
