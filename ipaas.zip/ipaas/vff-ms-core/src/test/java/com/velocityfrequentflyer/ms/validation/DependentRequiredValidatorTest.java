package com.velocityfrequentflyer.ms.validation;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DependentRequiredValidatorTest {

  private static Validator validator;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    validator = validatorFactory.getValidator();
  }

  private Address addr;

  @Before
  public void setUp() throws Exception {
    addr = new Address();
    addr.setCityName("City");
    addr.setAddressType("HOME");
    addr.setAddressLine(Arrays.asList("1 One St"));
  }

  @Test
  public void testCountryNull() {
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(0, constraintViolations.size());
  }

  @Test
  public void testCountryAU() {
    addr.setCountry("AU");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(2, constraintViolations.size());
  }

  @Test
  public void testCountryAUBlankPCode() {
    addr.setCountry("AU");
    addr.setPostalCode("");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(2, constraintViolations.size());
  }

  @Test
  public void testCountryAUNonBlankPCode() {
    addr.setCountry("AU");
    addr.setPostalCode("2000");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(1, constraintViolations.size());
  }

  @Test
  public void testCountryNZ() {
    addr.setCountry("NZ");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(1, constraintViolations.size());
  }

  @Test
  public void testCountryNZBlankState() {
    addr.setCountry("NZ");
    addr.setStateProv("");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(1, constraintViolations.size());
  }

  @Test
  public void testCountryNZBlankPCode() {
    addr.setCountry("NZ");
    addr.setPostalCode("");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(1, constraintViolations.size());
  }

  @Test
  public void testCountryOther() {
    addr.setCountry("US");
    Set<ConstraintViolation<Address>> constraintViolations = validator.validate(addr);
    assertEquals(0, constraintViolations.size());
  }
}

@DependentRequired.List({
  @DependentRequired(
      dependentProperty = "country",
      dependentValue = "NZ",
      requiredProperty = "postalCode"),
  @DependentRequired(
      dependentProperty = "country",
      dependentValue = "AU",
      requiredProperty = "stateProv"),
  @DependentRequired(
      dependentProperty = "country",
      dependentValue = "AU",
      requiredProperty = "postalCode")
})
class Address {
  @NotNull private List<String> addressLine;

  @NotNull
  @Pattern(regexp = "^([a-zA-Z]{1,64})$")
  private String cityName;

  @Pattern(regexp = "^([0-9]{1,16})|()$")
  private String postalCode;

  @Pattern(regexp = "^([a-zA-Z]{1,32})$")
  private String county;

  @Pattern(regexp = "^([a-zA-Z]{2,3})|()$")
  private String stateProv;

  @Pattern(regexp = "^([A-Z]{2})$")
  private String country;

  @NotNull
  @Pattern(regexp = "^(HOME|BUSINESS)$")
  private String addressType;

  @Pattern(regexp = "^([1-2]{1})$")
  private String orderSequenceNumber;

  public List<String> getAddressLine() {
    return addressLine;
  }

  public void setAddressLine(List<String> addressLine) {
    this.addressLine = addressLine;
  }

  public String getCityName() {
    return cityName;
  }

  public void setCityName(String cityName) {
    this.cityName = cityName;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getCounty() {
    return county;
  }

  public void setCounty(String county) {
    this.county = county;
  }

  public String getStateProv() {
    return stateProv;
  }

  public void setStateProv(String stateProv) {
    this.stateProv = stateProv;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getAddressType() {
    return addressType;
  }

  public void setAddressType(String addressType) {
    this.addressType = addressType;
  }

  public String getOrderSequenceNumber() {
    return orderSequenceNumber;
  }

  public void setOrderSequenceNumber(String orderSequenceNumber) {
    this.orderSequenceNumber = orderSequenceNumber;
  }
}
