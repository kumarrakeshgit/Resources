package com.velocityfrequentflyer.ms.exception;

import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.DETAIL;
import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.TITLE;
import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.TYPE;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ServiceProviderErrorMapperTest {

  private ServiceProviderErrorMapper underTest;

  @Before
  public void setUp() throws Exception {
    underTest = new ServiceProviderErrorMapper();
  }

  @Test
  public void assertNumberOfErrors() {
    assertThat(underTest.getErrorMap()).hasSize(156);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void assertErrorsCanNotBeChanged() {
    underTest.getErrorMap().put("new random error", null);
  }

  @Test
  public void testErrorCodeMapper() {
    Map<String, String> errorDetails = underTest.getErrorDetails("LTY-0267");
    assertThat(errorDetails)
        .isNotNull()
        .hasSize(3)
        .containsEntry(TITLE.getValue(), "Invalid certificate number")
        .containsEntry(TYPE.getValue(), "loyalty:InvalidCertificateNumber")
        .containsEntry(DETAIL.getValue(), "The certificate number is not found.");
  }

  @Test
  public void testErrorCodeMapper_MissingEntry() {
    Map<String, String> errorDetails = underTest.getErrorDetails("LTY-CANNOTFINDTHISCODE");
    assertThat(errorDetails).isNotNull().hasSize(0);
  }
}
