package com.velocityfrequentflyer.ms.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.MsApplication;
import com.velocityfrequentflyer.ms.dto.MsInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {MsApplication.class},
    webEnvironment = WebEnvironment.RANDOM_PORT)
public class MsInfoControllerTest {

  @Autowired private TestRestTemplate restTemplate;

  @Test
  public void testValidGreetResponse() {
    ResponseEntity<MsInfo> entity = this.restTemplate.getForEntity("/ms-info", MsInfo.class);
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.OK);
    assertThat(entity.getBody().getName()).isEqualTo("test-api");
  }
}
