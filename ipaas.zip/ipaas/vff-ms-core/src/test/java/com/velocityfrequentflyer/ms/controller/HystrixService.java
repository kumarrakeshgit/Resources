package com.velocityfrequentflyer.ms.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.velocityfrequentflyer.ms.exception.ServiceProviderException;
import org.springframework.stereotype.Service;

@Service
public class HystrixService {

  @HystrixCommand(commandKey = "HystrixServiceKey")
  public String someCall() {
    throw new ServiceProviderException("Service error", "500", "Downstream service error");
  }
}
