package com.velocityfrequentflyer.ms.subtier.service;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList;
import com.velocityfrequentflyer.ms.exception.NotFoundException;
import com.velocityfrequentflyer.ms.subtier.dto.SubTier;
import java.util.Arrays;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class SubTierDBServiceTest {

  private SubTierDBService service = new SubTierDBService();
  private DynamoDBMapper mapper = mock(DynamoDBMapper.class);

  @Before
  public void setUp() throws Exception {
    ReflectionTestUtils.setField(service, "dynamoEndpoint", "https://localhost");
    service.init();

    ReflectionTestUtils.setField(service, "dynamoDBMapper", mapper);
  }

  @Test(expected = NotFoundException.class)
  public void query() {
    when(mapper.query(any(), any())).thenReturn(mock(PaginatedQueryList.class));
    service.getTier("SR");
  }

  @Test
  public void save() {
    service.save(Arrays.asList(new SubTier("SR")));
  }
}
