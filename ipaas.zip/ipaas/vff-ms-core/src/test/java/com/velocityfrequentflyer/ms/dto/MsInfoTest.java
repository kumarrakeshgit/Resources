package com.velocityfrequentflyer.ms.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.MsApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {MsApplication.class})
public class MsInfoTest {

  @Autowired private MsInfo msInfo;

  @Test
  public void testAppEnvironmentPropertiesExist() {
    assertThat(msInfo.getEnvironmentName()).isEqualTo("test");
    assertThat(msInfo.getEnvironmentNumber()).isEqualTo("99");
    assertThat(msInfo.getAccountId()).isEqualTo("123123123");
    assertThat(msInfo.getRegion()).isEqualTo("us-west-2");

    assertThat(msInfo.getBranch()).isEqualTo("master");
    assertThat(msInfo.getUrl()).isEqualTo("http://adfadfa");
    assertThat(msInfo.getCommit()).isEqualTo("adfasdf34242");

    assertThat(msInfo.getName()).isEqualTo("test-api");
    assertThat(msInfo.getDescription()).isEqualTo("Test API");

    assertThat(msInfo.getBuild()).isEqualTo("DEADBEEF");
    assertThat(msInfo.getVersion()).isEqualTo("1.0.0");
    assertThat(msInfo.getTimestamp()).isEqualTo("1970-01-02T20:17:36.789+10:00");
  }
}
