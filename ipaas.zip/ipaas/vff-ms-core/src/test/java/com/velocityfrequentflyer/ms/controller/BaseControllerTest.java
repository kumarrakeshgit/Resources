package com.velocityfrequentflyer.ms.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.auth.RequestContext;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

/** @author Deniss Sudak */
@RunWith(MockitoJUnitRunner.class)
public class BaseControllerTest {

  private BaseController controller;

  @Rule public ExpectedException thrown = ExpectedException.none();

  @Before
  public void setup() {
    controller = new BaseController() {};
  }

  /** It should return memberId from RequestContext */
  @Test
  public void testGetMemberId() {
    String memberId = "Alice";
    RequestContext.setCurrent(new RequestContext(memberId, "doesn't matter"));

    assertThat(controller.getMemberId()).isEqualTo(memberId);
  }
}
