package com.velocityfrequentflyer.ms.auth;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.util.Base64URL;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.oauth2.sdk.GeneralException;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import java.io.IOException;
import java.text.ParseException;
import java.time.Instant;
import java.util.Collections;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class JwtTest {

  private static final String ISSUER_URI = "https://someurl";
  private static final String MEMBER_ID_CLAIM_KEY = "preferred_username";
  private static final String DUMMY_MEMBER_ID = "123456789";

  @Mock private JwtDelegate jwtDelegate;

  @Mock private SignedJWT signedJWT;

  private Jwt jwt;

  @Before
  public void setup() {
    jwt = new Jwt();
    jwt.setIssuerUri(ISSUER_URI);
    jwt.setJwtDelegate(jwtDelegate);
    jwt.setMemberIdClaimKey(MEMBER_ID_CLAIM_KEY);
  }

  @Test
  public void testValidClaimSetFromToken()
      throws ParseException, IOException, GeneralException, ExecutionException, JOSEException,
          AuthorizationException {
    OIDCProviderMetadata metadata = mock(OIDCProviderMetadata.class);
    when(jwtDelegate.parseSignedJwt("signed.jwt.token")).thenReturn(signedJWT);
    when(jwtDelegate.fetchOicdProviderMetadata(eq(ISSUER_URI), anyInt(), anyInt()))
        .thenReturn(metadata);

    RSAKey key = getDummyRSAKey();
    JWTClaimsSet claimsSet = getDummyClaimsSet(60);
    when(signedJWT.getJWTClaimsSet()).thenReturn(claimsSet);

    JWKSet jwkSet = mock(JWKSet.class);
    when(jwkSet.getKeys()).thenReturn(Collections.singletonList(key));
    when(jwtDelegate.fetchJwkSet(eq(metadata), anyInt(), anyInt(), anyInt())).thenReturn(jwkSet);

    when(signedJWT.getHeader()).thenReturn(new JWSHeader(JWSAlgorithm.RS256));
    when(signedJWT.verify(any())).thenReturn(true);

    assertEquals(claimsSet, jwt.fetchVerifiedClaimSet("signed.jwt.token"));
  }

  @Test
  public void testValidMemberIdFromToken()
      throws ParseException, IOException, GeneralException, ExecutionException, JOSEException,
          AuthorizationException {
    OIDCProviderMetadata metadata = mock(OIDCProviderMetadata.class);
    when(jwtDelegate.parseSignedJwt("signed.jwt.token")).thenReturn(signedJWT);
    when(jwtDelegate.fetchOicdProviderMetadata(eq(ISSUER_URI), anyInt(), anyInt()))
        .thenReturn(metadata);

    RSAKey key = getDummyRSAKey();
    JWTClaimsSet claimsSet = getDummyClaimsSet(60);
    when(signedJWT.getJWTClaimsSet()).thenReturn(claimsSet);

    JWKSet jwkSet = mock(JWKSet.class);
    when(jwkSet.getKeys()).thenReturn(Collections.singletonList(key));
    when(jwtDelegate.fetchJwkSet(eq(metadata), anyInt(), anyInt(), anyInt())).thenReturn(jwkSet);

    when(signedJWT.getHeader()).thenReturn(new JWSHeader(JWSAlgorithm.RS256));
    when(signedJWT.verify(any())).thenReturn(true);

    assertEquals(DUMMY_MEMBER_ID, jwt.fetchVerifiedMemberId("signed.jwt.token"));
  }

  @Test(expected = AuthorizationException.class)
  public void testInvalidJwtString() throws AuthorizationException {
    jwt.setJwtDelegate(new JwtDelegate());
    jwt.fetchVerifiedMemberId("invalid.token");
  }

  @Test(expected = AuthorizationException.class)
  public void testInvalidSignature()
      throws ParseException, IOException, GeneralException, ExecutionException, JOSEException,
          AuthorizationException {
    OIDCProviderMetadata metadata = mock(OIDCProviderMetadata.class);
    when(jwtDelegate.parseSignedJwt("signed.jwt.token")).thenReturn(signedJWT);
    when(jwtDelegate.fetchOicdProviderMetadata(eq(ISSUER_URI), anyInt(), anyInt()))
        .thenReturn(metadata);

    RSAKey key = getDummyRSAKey();
    JWTClaimsSet claimsSet = getDummyClaimsSet(60);
    when(signedJWT.getJWTClaimsSet()).thenReturn(claimsSet);

    JWKSet jwkSet = mock(JWKSet.class);
    when(jwkSet.getKeys()).thenReturn(Collections.singletonList(key));
    when(jwtDelegate.fetchJwkSet(eq(metadata), anyInt(), anyInt(), anyInt())).thenReturn(jwkSet);

    when(signedJWT.getHeader()).thenReturn(new JWSHeader(JWSAlgorithm.RS256));
    when(signedJWT.verify(any())).thenReturn(false); // REPRESENTS INVALID SIGNATURE

    jwt.fetchVerifiedClaimSet("signed.jwt.token");
  }

  @Test(expected = AuthorizationException.class)
  public void testExpiredToken()
      throws ParseException, IOException, GeneralException, ExecutionException, JOSEException,
          AuthorizationException {
    when(jwtDelegate.parseSignedJwt("signed.jwt.token")).thenReturn(signedJWT);

    JWTClaimsSet claimsSet = getDummyClaimsSet(-60);
    when(signedJWT.getJWTClaimsSet()).thenReturn(claimsSet);

    jwt.fetchVerifiedClaimSet("signed.jwt.token");
  }

  private RSAKey getDummyRSAKey() {
    return new RSAKey.Builder(
            new Base64URL(
                "x7i2l73TIlqUlHVWr-7chzsCJZ-WjL_XJ6oXxP3cmLFGGnyEpWL44ox-CE77YvJPeWhbiP3Jp1vXEKfTYkE8Gqp6tNlk_SSV_SHA_PQex4hFchkmqBDOG9dpe5xDlVj1aSMZ3Qxl-JAQIhYQdcYRKG481Kscm9xQT2ngmPQc9xP8MYQJEIU4IuTRc6S4gIrn1RFTd_IX_YLvsOF8TrdeXn1AOlp6Oy9i9zzJL8DYHEBl4Jp3ICoItL95P1XhTU3MzjgJEQnM4W_f21SFAGEg4yWzPMLGjqQJdA16naDTyan49kRsfQa41t5_vLO5Q8kexBVq-J211IUoqTU5CDULVQ"),
            new Base64URL("AQAB"))
        .algorithm(JWSAlgorithm.RS256)
        .build();
  }

  private JWTClaimsSet getDummyClaimsSet(int expiresIn) {
    return new JWTClaimsSet.Builder()
        .expirationTime(Date.from(Instant.now().plusSeconds(expiresIn)))
        .claim(MEMBER_ID_CLAIM_KEY, DUMMY_MEMBER_ID)
        .build();
  }
}
