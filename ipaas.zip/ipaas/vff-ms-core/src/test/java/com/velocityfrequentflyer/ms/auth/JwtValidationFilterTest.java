package com.velocityfrequentflyer.ms.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author Alex Kuchar
 * @author Deniss Sudak
 */
@RunWith(MockitoJUnitRunner.class)
public class JwtValidationFilterTest {

  @Rule public ExpectedException thrown = ExpectedException.none();

  @Mock private Jwt jwt;

  @Mock private HttpServletRequest request;

  @Mock private HttpServletResponse response;

  @Mock private FilterChain chain;

  @Mock private FilterConfig filterConfig;

  private JwtValidationFilter filter;

  private String jwtIdToken = "some-token";
  private String correlationId = "abcdef";
  private String verifiedMemberId = "123456";

  @Before
  public void setup() {
    reset(request, jwt);

    filter = new JwtValidationFilter();
    filter.setCorrelationIdHeader("X-Correlation-ID");
    filter.setCorrelationIdMdcTag("CORRELATION_ID");
    filter.setJwtIdTokenHeader("X-JWT-ID-Token");
    filter.setMemberIdMdcTag("MEMBER_ID");
    filter.setMajorVersion("v1");
    filter.setSecureMsPrefixes(" Accounts, airports");
    filter.setJwt(jwt);
    filter.init(filterConfig);

    when(request.getHeader("X-JWT-ID-Token")).thenReturn(jwtIdToken);
    when(request.getHeader("X-Correlation-ID")).thenReturn(correlationId);
    when(jwt.fetchVerifiedMemberId("some-token")).thenReturn(verifiedMemberId);
  }

  @After
  public void teardown() {
    RequestContext.clearCurrent();
  }

  /**
   * It should populate RequestContext with null correlation id if it can't be found in the header.
   * Correlation id is used for logging purposed and is expected to be populated by Apigee
   */
  @Test
  public void testWhenCorrelationIdMissing() throws IOException, ServletException {
    when(request.getHeader("X-Correlation-ID")).thenReturn(null);

    filter.doFilter(request, response, chain);

    assertThat(RequestContext.getCurrent()).isNotNull();
    assertThat(RequestContext.getCurrent().getCorrelationId()).isNullOrEmpty();
  }

  /**
   * It should populate RequestContext with null memberId if JWT token can't be found in the header
   * and resource is not protected. The resource is protected when its URI starts with
   * /majorVersion/msRoot path. For example /v1/accounts
   */
  @Test
  public void testWhenJwtHeaderMissing() throws IOException, ServletException {
    when(request.getHeader("X-JWT-ID-Token")).thenReturn(null);
    when(request.getRequestURI()).thenReturn("/info");

    filter.doFilter(request, response, chain);

    assertThat(RequestContext.getCurrent()).isNotNull();
    assertThat(RequestContext.getCurrent().getMemberId()).isNullOrEmpty();
  }

  /**
   * It should throw an exception if JWT token is missing in the header and the resource is
   * protected. The resource is protected when its URI starts with /{majorVersion}/{msRoot} path.
   * For example /v1/accounts. {msRoot} is one of the comma separated values assigned to
   * secureMsPrefixes field.
   */
  @Test(expected = AuthorizationException.class)
  public void testWhenJwtHeaderMissingAndResourceIsProtected()
      throws IOException, ServletException {
    when(request.getHeader("X-JWT-ID-Token")).thenReturn(null);
    when(request.getRequestURI()).thenReturn("/v1/accounts/me");

    filter.doFilter(request, response, chain);
  }

  /**
   * It should throw an exception if JWT token is missing in the header and the resource is
   * protected. The resource is protected when its URI starts with /{majorVersion}/{msRoot} path.
   * For example /v1/accounts. {msRoot} is one of the comma separated values assigned to
   * secureMsPrefixes field.
   */
  @Test(expected = AuthorizationException.class)
  public void testWhenJwtHeaderMissingAndResourceIsProtected2()
      throws IOException, ServletException {
    when(request.getHeader("X-JWT-ID-Token")).thenReturn(null);
    when(request.getRequestURI()).thenReturn("/v1/AirPorts/me");

    filter.doFilter(request, response, chain);
  }

  @Test
  public void testInvalidJwtFails() throws IOException, ServletException, AuthorizationException {
    String expectedErrorMessage = "Invalid JWT";
    when(jwt.fetchVerifiedMemberId(jwtIdToken))
        .thenThrow(new AuthorizationException(expectedErrorMessage));

    thrown.expect(AuthorizationException.class);
    thrown.expectMessage(expectedErrorMessage);

    filter.doFilter(request, response, chain);
  }

  @Test
  public void testRequestContextIsSet() throws IOException, ServletException {

    filter.doFilter(request, response, chain);

    assertThat(RequestContext.getCurrent()).isNotNull();
    assertThat(RequestContext.getCurrent().getCorrelationId()).isEqualTo(correlationId);
    assertThat(RequestContext.getCurrent().getMemberId()).isEqualTo(verifiedMemberId);
  }

  @Test
  public void testRequestContextIsClearedUponDestroy() {
    RequestContext.setCurrent(new RequestContext("123456", "abcdef"));
    filter.destroy();
    assertNull(RequestContext.getCurrent());
  }

  @Test
  public void testTestMemberId() throws AuthorizationException, IOException, ServletException {
    String testMemberId = "123456";
    filter.setTestMemberId(testMemberId);

    filter.doFilter(request, response, chain);

    assertThat(RequestContext.getCurrent()).isNotNull();
    assertThat(RequestContext.getCurrent().getCorrelationId()).isEqualTo(correlationId);
    assertThat(RequestContext.getCurrent().getMemberId()).isEqualTo(testMemberId);
  }

  @Test
  public void testTestCorrelationId() throws AuthorizationException, IOException, ServletException {
    String testCorrelationId = "abcdefzzzz";
    filter.setTestCorrelationId(testCorrelationId);

    filter.doFilter(request, response, chain);

    assertThat(RequestContext.getCurrent()).isNotNull();
    assertThat(RequestContext.getCurrent().getCorrelationId()).isEqualTo(testCorrelationId);
    assertThat(RequestContext.getCurrent().getMemberId()).isEqualTo(verifiedMemberId);
  }
}
