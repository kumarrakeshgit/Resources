package com.velocityfrequentflyer.ms.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.velocityfrequentflyer.ms.dto.AccountStatus;
import java.io.IOException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest
@ContextConfiguration(classes = {WebConfig.class})
public class WebConfigTest {

  @Autowired private RequestMappingHandlerAdapter handlerAdapter;

  @Before
  public void setUp() throws Exception {}

  @Test
  public void testingMessageConverters() throws IOException {
    assertThat(handlerAdapter.getMessageConverters()).isNotEmpty();

    MappingJackson2HttpMessageConverter httpMessageConverter =
        (MappingJackson2HttpMessageConverter) handlerAdapter.getMessageConverters().get(0);
    ObjectMapper objectMapper = httpMessageConverter.getObjectMapper();

    String payload =
        "{\n"
            + "    \"loyaltyMembershipID\": \"1170286603\",\n"
            + "    \"currentPointsBalance\": 0,\n"
            + "    \"currentPointsBalanceExpiryDate\": \"2020-07-31\",\n"
            + "    \"nearingExpiryDate\": false,\n"
            + "    \"statusCreditsBalance\": 1000,\n"
            + "    \"statusSectorsBalance\": 8,\n"
            + "    \"benefitPeriodStatusCreditsBalance\": 1000,\n"
            + "    \"benefitPeriodStatusSectorsBalance\": 8,\n"
            + "    \"benefitPeriodExpiryDate\": \"2018-08-22\",\n"
            + "    \"updateDate\": \"2018-07-12\",\n"
            + "    \"currentTierInfo\": {\n"
            + "      \"tierLevel\": \"G\",\n"
            + "      \"subTierLevel\": \"S\"\n"
            + "    },\n"
            + "    \"downgradeTierInfo\": {\n"
            + "      \"tierLevel\": \"S\",\n"
            + "      \"subTierLevel\": \"S\",\n"
            + "      \"creditsLeft\": 0,\n"
            + "      \"sectorsLeft\": 0,\n"
            + "      \"creditsRequired\": 400,\n"
            + "      \"sectorsRequired\": 4\n"
            + "    },\n"
            + "    \"upgradeTierInfo\": {\n"
            + "      \"tierLevel\": \"P\",\n"
            + "      \"subTierLevel\": \"S\",\n"
            + "      \"creditsLeft\": 0,\n"
            + "      \"sectorsLeft\": 0,\n"
            + "      \"creditsRequired\": 1000,\n"
            + "      \"sectorsRequired\": 8\n"
            + "    },\n"
            + "    \"accountStatusCode\": \"ACTIVE\",\n"
            + "    \"qualPeriodEnd\": \"2018-07-22\",\n"
            + "    \"underReview\": true,\n"
            + "    \"validityPeriod\": 12\n"
            + "  }";

    AccountStatus accountStatus = objectMapper.readValue(payload, AccountStatus.class);
    assertThat(accountStatus).isNotNull();
  }

  @Test
  public void testingMessageConverters_UnknownProperty() throws IOException {
    assertThat(handlerAdapter.getMessageConverters()).isNotEmpty();

    MappingJackson2HttpMessageConverter httpMessageConverter =
        (MappingJackson2HttpMessageConverter) handlerAdapter.getMessageConverters().get(0);
    ObjectMapper objectMapper = httpMessageConverter.getObjectMapper();

    String payload =
        "{\n"
            + "    \"loyaltyMembershipID\": \"1170286603\",\n"
            + "    \"currentPointsBalance\": 0,\n"
            + "    \"currentPointsBalanceExpiryDate\": \"2020-07-31\",\n"
            + "    \"nearingExpiryDate\": false,\n"
            + "    \"statusCreditsBalance\": 1000,\n"
            + "    \"statusSectorsBalance\": 8,\n"
            + "    \"benefitPeriodStatusCreditsBalance\": 1000,\n"
            + "    \"benefitPeriodStatusSectorsBalance\": 8,\n"
            + "    \"benefitPeriodExpiryDate\": \"2018-08-22\",\n"
            + "    \"updateDate\": \"2018-07-12\",\n"
            + "    \"currentTierInfo\": {\n"
            + "      \"tierLevel\": \"G\",\n"
            + "      \"subTierLevel\": \"S\"\n"
            + "    },\n"
            + "    \"downgradeTierInfo\": {\n"
            + "      \"tierLevel\": \"S\",\n"
            + "      \"subTierLevel\": \"S\",\n"
            + "      \"creditsLeft\": 0,\n"
            + "      \"sectorsLeft\": 0,\n"
            + "      \"creditsRequired\": 400,\n"
            + "      \"sectorsRequired\": 4\n"
            + "    },\n"
            + "    \"upgradeTierInfo\": {\n"
            + "      \"tierLevel\": \"P\",\n"
            + "      \"subTierLevel\": \"S\",\n"
            + "      \"creditsLeft\": 0,\n"
            + "      \"sectorsLeft\": 0,\n"
            + "      \"creditsRequired\": 1000,\n"
            + "      \"sectorsRequired\": 8\n"
            + "    },\n"
            + "    \"accountStatusCode\": \"ACTIVE\",\n"
            + "    \"qualPeriodEnd\": \"2018-07-22\",\n"
            + "    \"underReview\": true,\n"
            + "    \"validityPeriod\": 12,\n"
            + "    \"THISISANEWPROPERTYTHATWEWILLNEVERSEE\": 9999999999999\n"
            + "  }";

    AccountStatus accountStatus = objectMapper.readValue(payload, AccountStatus.class);
    assertThat(accountStatus).isNotNull();
  }

  @Test
  public void testingMessageConverters_MissingProperty() throws IOException {
    assertThat(handlerAdapter.getMessageConverters()).isNotEmpty();

    MappingJackson2HttpMessageConverter httpMessageConverter =
        (MappingJackson2HttpMessageConverter) handlerAdapter.getMessageConverters().get(0);
    ObjectMapper objectMapper = httpMessageConverter.getObjectMapper();

    String payload =
        "{\n"
            + "    \"loyaltyMembershipID\": \"1170286603\",\n"
            + "    \"currentPointsBalance\": 0,\n"
            + "    \"currentPointsBalanceExpiryDate\": \"2020-07-31\"\n"
            + "  }";

    AccountStatus accountStatus = objectMapper.readValue(payload, AccountStatus.class);
    assertThat(accountStatus).isNotNull();
  }
}
