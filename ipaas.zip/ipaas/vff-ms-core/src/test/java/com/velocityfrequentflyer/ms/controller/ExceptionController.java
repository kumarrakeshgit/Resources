package com.velocityfrequentflyer.ms.controller;

import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.netflix.hystrix.exception.HystrixRuntimeException.FailureType;
import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import com.velocityfrequentflyer.ms.exception.NotFoundException;
import com.velocityfrequentflyer.ms.exception.ServiceProviderException;
import com.velocityfrequentflyer.ms.exception.ValidationException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ExceptionController extends BaseController {

  @RequestMapping(value = "/validation", method = RequestMethod.GET, produces = "application/json")
  public Object validationException() {
    throw new ValidationException("Validation error", "400", "Incorrect name");
  }

  @RequestMapping(
      value = "/missing-context",
      method = RequestMethod.GET,
      produces = "application/json")
  public Object missingContextException() {
    throw new ValidationException("Missing Context", "400", "No Request Context set");
  }

  @RequestMapping(value = "/service", method = RequestMethod.GET, produces = "application/json")
  public Object serviceException() {
    throw new ServiceProviderException("Service error", "LTY-0010", "Downstream service error");
  }

  @RequestMapping(value = "/service2", method = RequestMethod.GET, produces = "application/json")
  public Object serviceException2() {
    throw new ServiceProviderException("Service error", "LTY-0036", "Downstream service error");
  }

  @RequestMapping(value = "/hystrix", method = RequestMethod.GET, produces = "application/json")
  public Object hystrixException() {
    throw new HystrixRuntimeException(FailureType.COMMAND_EXCEPTION, null, null, null, null);
  }

  @RequestMapping(value = "/auth", method = RequestMethod.GET, produces = "application/json")
  public Object authException() {
    throw new AuthorizationException("auth");
  }

  @RequestMapping(value = "/notfound", method = RequestMethod.GET, produces = "application/json")
  public Object notFoundException() {
    throw new NotFoundException("", "", "");
  }
}
