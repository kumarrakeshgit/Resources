package com.velocityfrequentflyer.ms.auth;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class RequestContextTest {

  @Test
  public void testContextIsUniquePerThread() throws InterruptedException {
    RequestContext ctx = new RequestContext("abc", "def");
    RequestContext.setCurrent(ctx);
    assertEquals(ctx, RequestContext.getCurrent());
    Thread t =
        new Thread(
            () -> {
              RequestContext otherCtx = new RequestContext("123", "456");
              RequestContext.setCurrent(otherCtx);
              assertEquals(otherCtx, RequestContext.getCurrent());
            });
    t.start();
    t.join();
    assertEquals(ctx, RequestContext.getCurrent());
  }

  @Test
  public void testClearedContextOnlyClearsCurrentThread() throws InterruptedException {
    RequestContext ctx = new RequestContext("abc", "def");
    RequestContext.setCurrent(ctx);
    assertEquals(ctx, RequestContext.getCurrent());
    Thread t = new Thread(RequestContext::clearCurrent);
    t.start();
    t.join();
    assertEquals(ctx, RequestContext.getCurrent());
  }

  @Test
  public void validEqualsAndHashCode() {
    RequestContext ctx = new RequestContext("abc", "123");
    assertEquals(ctx, new RequestContext("abc", "123"));
    assertNotEquals(ctx, new Object());
    assertNotEquals(ctx, new RequestContext("def", "456"));

    assertEquals(ctx.hashCode(), new RequestContext("abc", "123").hashCode());
    assertNotEquals(ctx.hashCode(), new RequestContext("def", "456").hashCode());
  }
}
