package com.velocityfrequentflyer.ms.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.velocityfrequentflyer.ms.MsApplication;
import com.velocityfrequentflyer.ms.dto.ErrorResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {MsApplication.class},
    webEnvironment = WebEnvironment.RANDOM_PORT)
public class HystrixControllerTest {

  @Autowired private TestRestTemplate restTemplate;

  @Test
  public void testHystrixException() {
    boolean circuitOpened = false;
    for (int i = 1; i <= 60; i++) {
      ResponseEntity<ErrorResponse> entity =
          this.restTemplate.getForEntity("/v1/hystrix-test", ErrorResponse.class);
      assertThat(entity.getStatusCode())
          .isIn(HttpStatus.BAD_REQUEST, HttpStatus.INTERNAL_SERVER_ERROR);
      if (entity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
        circuitOpened = true;
        break;
      }
    }

    assertThat(circuitOpened).isEqualTo(true);
  }
}
