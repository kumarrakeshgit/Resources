package com.velocityfrequentflyer.ms.exception;

import org.springframework.http.HttpStatus;

public class AuthorizationException extends MsException {

  private static final long serialVersionUID = 7914930104754154654L;

  public AuthorizationException(String message) {
    super(message, HttpStatus.UNAUTHORIZED.toString(), message);
  }

  public AuthorizationException(String message, String cause) {
    super(message, HttpStatus.UNAUTHORIZED.toString(), cause);
  }

  public AuthorizationException(String message, Throwable cause) {
    super(message, HttpStatus.UNAUTHORIZED.toString(), cause.getMessage());
  }
}
