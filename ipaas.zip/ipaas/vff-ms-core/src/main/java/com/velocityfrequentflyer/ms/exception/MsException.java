package com.velocityfrequentflyer.ms.exception;

public class MsException extends RuntimeException {

  private static final long serialVersionUID = 6356687781555676671L;

  private String code;
  private String cause;

  MsException() {}

  public MsException(String message, String code, String cause) {
    super(message);
    this.code = code;
    this.cause = cause;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getCauseString() {
    return cause;
  }

  public void setCause(String cause) {
    this.cause = cause;
  }
}
