package com.velocityfrequentflyer.ms.subtier.service;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.velocityfrequentflyer.ms.exception.NotFoundException;
import com.velocityfrequentflyer.ms.service.DynamoDBBaseService;
import com.velocityfrequentflyer.ms.subtier.dto.SubTier;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SubTierDBService extends DynamoDBBaseService {
  private static final Logger log = LoggerFactory.getLogger(SubTierDBService.class);

  public SubTierDBService() {
    super("subtier");
    log.debug("Contructing SubTierDBService");
  }

  @HystrixCommand
  public SubTier getTier(String tierCode) throws NotFoundException {
    DynamoDBQueryExpression<SubTier> query = new DynamoDBQueryExpression<SubTier>();
    query.setHashKeyValues(new SubTier(tierCode));
    List<SubTier> result = dynamoDBMapper.query(SubTier.class, query);

    if (result.size() == 0) {
      throw new NotFoundException(
          "SubTier for tierCode: " + tierCode + " not found", "404", "Doesnt exist in DB");
    }
    log.debug("subtier by id " + result.get(0));
    return result.get(0);
  }

  @HystrixCommand
  public List<FailedBatch> save(List<SubTier> subtierList) {
    log.debug("save subtierList=" + subtierList);
    return dynamoDBMapper.batchSave(subtierList);
  }
}
