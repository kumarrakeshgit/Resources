package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@JsonInclude(Include.NON_NULL)
public class FlightInfo {
  @ApiModelProperty(notes = "Flight origin airport", required = true)
  private Airport origin;

  @ApiModelProperty(notes = "Flight destination airport", required = true)
  private Airport destination;

  @ApiModelProperty(notes = "Flight intermediate stops")
  private List<Airport> via;

  @ApiModelProperty(
      notes = "Destination groups based on points information and geographical location",
      required = true)
  private Groups groups;

  @ApiModelProperty(notes = "Destination tags")
  private List<String> tags;

  @ApiModelProperty(
      notes = "Flight class",
      required = true,
      allowableValues = "Economy,Business,Premium")
  private String flightClass;

  @ApiModelProperty(notes = "Flight type", required = true, allowableValues = "oneway,return")
  private String flightType;

  @ApiModelProperty(notes = "Velocity points required for trip", required = true)
  private int points;

  @ApiModelProperty(notes = "Trip cost", required = true)
  private BigDecimal charges;

  @ApiModelProperty(notes = "Number of passengers charges calculated for")
  private int pax;

  @ApiModelProperty(notes = "Currency of charges")
  private String currency;

  @ApiModelProperty(
      notes = "Timestamp of the points, charges and fees data upload in ISO-8601 format")
  private Date chargesTimestamp;

  public boolean isReturn() {
    return "return".equals(flightType);
  }

  public int getPax() {
    return pax;
  }

  public void setPax(int pax) {
    this.pax = pax;
  }

  public String getFlightClass() {
    return flightClass;
  }

  public void setFlightClass(String flightClass) {
    this.flightClass = flightClass;
  }

  public Airport getOrigin() {
    return origin;
  }

  public void setOrigin(Airport orig) {
    this.origin = orig;
  }

  public Airport getDestination() {
    return destination;
  }

  public void setDestination(Airport dest) {
    this.destination = dest;
  }

  public List<Airport> getVia() {
    return via;
  }

  public void setVia(List<Airport> via) {
    this.via = via;
  }

  public Groups getGroups() {
    return groups;
  }

  public void setGroups(Groups groups) {
    this.groups = groups;
  }

  public List<String> getTags() {
    return tags;
  }

  public void setTags(List<String> tags) {
    this.tags = tags;
  }

  public String getFlightType() {
    return flightType;
  }

  public void setFlightType(String flightType) {
    this.flightType = flightType;
  }

  public int getPoints() {
    return points;
  }

  public void setPoints(int points) {
    this.points = points;
  }

  public BigDecimal getCharges() {
    return charges;
  }

  public void setCharges(BigDecimal charges) {
    this.charges = charges;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public Date getChargesTimestamp() {
    return chargesTimestamp;
  }

  public void setChargesTimestamp(Date chargesTimestamp) {
    this.chargesTimestamp = chargesTimestamp;
  }

  @Override
  public String toString() {
    return "FlightInfo [origin="
        + origin
        + ", destination="
        + destination
        + ", via="
        + via
        + ", groups="
        + groups
        + "flightClass="
        + flightClass
        + ", flightType="
        + flightType
        + ", points="
        + points
        + ", charges="
        + charges
        + ", currency="
        + currency
        + ", chargesTimestamp="
        + chargesTimestamp
        + "]";
  }
}
