package com.velocityfrequentflyer.ms.dto;

public class OrigDestClassRequest {
  private String origin;
  private String destination;
  private String flightClass;
  private int pax;
  private boolean oneway;

  public OrigDestClassRequest() {}

  public OrigDestClassRequest(
      String origin, String destination, String flightClass, int pax, boolean oneway) {
    super();
    this.origin = origin;
    this.destination = destination;
    this.flightClass = flightClass;
    this.pax = pax;
    this.oneway = oneway;
  }

  public String getOrigin() {
    return origin;
  }

  public void setOrigin(String origin) {
    this.origin = origin;
  }

  public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

  public String getFlightClass() {
    return flightClass;
  }

  public void setFlightClass(String flightClass) {
    this.flightClass = flightClass;
  }

  public int getPax() {
    return pax;
  }

  public void setPax(int pax) {
    this.pax = pax;
  }

  public boolean isOneway() {
    return oneway;
  }

  public void setOneway(boolean oneway) {
    this.oneway = oneway;
  }

  @Override
  public String toString() {
    return "OrigDestClassRequest [origin="
        + origin
        + ", destination="
        + destination
        + ", flightClass="
        + flightClass
        + ", pax="
        + pax
        + ", oneway="
        + oneway
        + "]";
  }
}
