package com.velocityfrequentflyer.ms.exception;

/** Indicates error related to the underlying service provider e.g. Velocity API */
public class ServiceProviderException extends MsException {

  private static final long serialVersionUID = 1034128680313678728L;

  public ServiceProviderException(String message, String code, String cause) {
    super(message, code, cause);
  }
}
