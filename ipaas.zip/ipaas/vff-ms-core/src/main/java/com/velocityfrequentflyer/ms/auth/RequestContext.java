package com.velocityfrequentflyer.ms.auth;

public class RequestContext {

  private static final ThreadLocal<RequestContext> CURRENT = new ThreadLocal<>();

  private String memberId;
  private String correlationId;
  private String jwtString;

  public RequestContext(String memberId, String correlationId) {
    this.memberId = memberId;
    this.correlationId = correlationId;
  }

  public RequestContext(String memberId, String correlationId, String jwtString) {
    this.memberId = memberId;
    this.correlationId = correlationId;
    this.jwtString = jwtString;
  }

  public static void setCurrent(RequestContext context) {
    CURRENT.set(context);
  }

  public static RequestContext getCurrent() {
    return CURRENT.get();
  }

  public static void clearCurrent() {
    CURRENT.remove();
  }

  public String getMemberId() {
    return memberId;
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public String getJwtString() {
    return jwtString;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!(obj instanceof RequestContext)) {
      return false;
    }

    RequestContext that = (RequestContext) obj;

    if (!getMemberId().equals(that.getMemberId())) {
      return false;
    }
    return getCorrelationId().equals(that.getCorrelationId());
  }

  @Override
  public int hashCode() {
    int result = getMemberId().hashCode();
    result = 31 * result + getCorrelationId().hashCode();
    return result;
  }
}
