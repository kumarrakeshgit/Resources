package com.velocityfrequentflyer.ms.subtier.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

/**
 * An Object that is used to store sub tier information
 *
 * @author quentinng
 */
@DynamoDBTable(tableName = "subtier")
public class SubTier {

  private static final String NA_TIER_CODE = "N/A";
  /** the TierCode is the concatenation of the subTierLevel and the tierLevel eg. CG */
  @DynamoDBHashKey
  @NotNull
  @Pattern(regexp = "^[A-Z][A-Z]$")
  private String tierCode;

  /** the tier level name. example Red, Silver, Gold, Platinum, VIP */
  @NotNull @DynamoDBAttribute private String hardTierName;

  /** This is the display name of the tier on the website. eg. Gold, Explorer Gold */
  @NotNull @DynamoDBAttribute private String displayName;

  @NotNull @DynamoDBAttribute private String tierDefinition;

  /**
   * The duration in months that is used in the calculation of maintaining the tier level. This is
   * the number of months that flights and sectors are used to identify the maintain the current
   * tier
   */
  @NotNull @DynamoDBAttribute private int durationInMonths;

  /** The validity period of the tier level */
  @NotNull @DynamoDBAttribute private int validityPeriodInMonths;

  /** The code to use when maintaining the tier */
  @NotNull
  @DynamoDBAttribute
  @Pattern(regexp = "^([A-Z][A-Z]|N/A)$")
  private String maintainTierCode;

  /** The number of points required within the durationInMonths that is used to maintain the tier */
  @NotNull @DynamoDBAttribute private int maintainPoints;

  /** The number of different sectors a member needs to fly to maintain the tier */
  @NotNull @DynamoDBAttribute private int maintainSectors;

  /** The tier code to use when downgrading to a lower tier. eg. CS */
  @NotNull
  @DynamoDBAttribute
  @Pattern(regexp = "^([A-Z][A-Z]|N/A)$")
  private String downgradeTierCode;

  /** The tier code to use when upgrading to a higher tier: CP */
  @NotNull
  @DynamoDBAttribute
  @Pattern(regexp = "^([A-Z][A-Z]|N/A)$")
  private String upgradeTierCode;

  /**
   * The number of points to accumulate during the durationInMonths to qualify to upgrade to higher
   * tier
   */
  @DynamoDBAttribute private int upgradePoints;

  /**
   * The number of different sectors a member needs to fly during the durationInMonths to qualify to
   * upgrade to a higher tier
   */
  @DynamoDBAttribute private int upgradeSectors;

  @DynamoDBAttribute private String additionRules;

  /** The hard tier code: eg G */
  @DynamoDBIgnore private String tierLevel;
  /** The subtier code: eg. C */
  @DynamoDBIgnore private String subTierLevel;

  public SubTier() {}

  public SubTier(String tierCode) {
    setTierCode(tierCode);
  }

  public SubTier(
      String tierCode,
      String hardTierName,
      String displayName,
      String tierDefinition,
      int durationInMonths,
      int validityPeriodInMonths,
      String maintainTierCode,
      int maintainPoints,
      int maintainSectors,
      String downgradeTierCode,
      String upgradeTierCode,
      int upgradePoints,
      int upgradeSectors,
      String additionRules) {
    setTierCode(tierCode);
    this.hardTierName = hardTierName;
    this.displayName = displayName;
    this.tierDefinition = tierDefinition;
    this.durationInMonths = durationInMonths;
    this.validityPeriodInMonths = validityPeriodInMonths;
    setMaintainTierCode(maintainTierCode);
    this.maintainPoints = maintainPoints;
    this.maintainSectors = maintainSectors;
    setDowngradeTierCode(downgradeTierCode);
    setUpgradeTierCode(upgradeTierCode);
    this.upgradePoints = upgradePoints;
    this.upgradeSectors = upgradeSectors;
    this.additionRules = additionRules;
  }

  public String getHardTierName() {
    return hardTierName;
  }

  public void setHardTierName(String hardTierName) {
    this.hardTierName = hardTierName;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getTierDefinition() {
    return tierDefinition;
  }

  public void setTierDefinition(String tierDefinition) {
    this.tierDefinition = tierDefinition;
  }

  public int getDurationInMonths() {
    return durationInMonths;
  }

  public void setDurationInMonths(int durationInMonths) {
    this.durationInMonths = durationInMonths;
  }

  public int getValidityPeriodInMonths() {
    return validityPeriodInMonths;
  }

  public void setValidityPeriodInMonths(int validityPeriodInMonths) {
    this.validityPeriodInMonths = validityPeriodInMonths;
  }

  public String getMaintainTierCode() {
    return maintainTierCode;
  }

  public void setMaintainTierCode(String maintainTierCode) {
    this.maintainTierCode = StringUtils.upperCase(maintainTierCode);
  }

  public int getMaintainPoints() {
    return maintainPoints;
  }

  public void setMaintainPoints(int maintainPoints) {
    this.maintainPoints = maintainPoints;
  }

  public int getMaintainSectors() {
    return maintainSectors;
  }

  public void setMaintainSectors(int maintainSectors) {
    this.maintainSectors = maintainSectors;
  }

  public String getDowngradeTierCode() {
    return downgradeTierCode;
  }

  public void setDowngradeTierCode(String downgradeTierCode) {
    this.downgradeTierCode = StringUtils.upperCase(downgradeTierCode);
  }

  public String getUpgradeTierCode() {
    return upgradeTierCode;
  }

  public void setUpgradeTierCode(String upgradeTierCode) {
    this.upgradeTierCode = StringUtils.upperCase(upgradeTierCode);
  }

  public int getUpgradePoints() {
    return upgradePoints;
  }

  public void setUpgradePoints(int upgradePoints) {
    this.upgradePoints = upgradePoints;
  }

  public int getUpgradeSectors() {
    return upgradeSectors;
  }

  public void setUpgradeSectors(int upgradeSectors) {
    this.upgradeSectors = upgradeSectors;
  }

  public String getAdditionRules() {
    return additionRules;
  }

  public void setAdditionRules(String additionRules) {
    this.additionRules = additionRules;
  }

  @DynamoDBIgnore
  public String getTierLevel() {
    return this.tierLevel;
  }

  @DynamoDBIgnore
  public String getSubTierLevel() {
    return this.subTierLevel;
  }

  public String getTierCode() {
    return tierCode;
  }

  public void setTierCode(String tierCode) {
    Assert.notNull(tierCode, "tierCode cannote be null");
    Assert.isTrue(
        tierCode.codePointCount(0, tierCode.length()) == 2,
        String.format(
            "%s is invalid. Tier Code is only a 2 character code comprising of the subtier level and the tier level",
            tierCode));
    this.tierCode = tierCode.toUpperCase();
    this.subTierLevel = String.valueOf(tierCode.charAt(0));
    this.tierLevel = String.valueOf(tierCode.charAt(1));
  }

  @DynamoDBIgnore
  public boolean isDowngradable() {
    return !NA_TIER_CODE.equals(downgradeTierCode);
  }

  @DynamoDBIgnore
  public boolean isUpgradable() {
    return !NA_TIER_CODE.equals(upgradeTierCode);
  }

  @Override
  public String toString() {
    return "SubTier [hardTierName = "
        + hardTierName
        + ", displayName = "
        + displayName
        + ",tierDefinition="
        + tierDefinition
        + ", durationInMonths="
        + durationInMonths
        + ", validityPeriodInMonths="
        + validityPeriodInMonths
        + ", this.maintainTierCode="
        + maintainTierCode
        + ", maintainPoints="
        + maintainPoints
        + ", maintainSectors="
        + maintainSectors
        + ", downgradeTierCode="
        + downgradeTierCode
        + ", upgradeTierCode="
        + upgradeTierCode
        + ", upgradePoints= "
        + upgradePoints
        + "upgradeSectors="
        + upgradeSectors
        + ", additionRules="
        + additionRules
        + "]";
  }
}
