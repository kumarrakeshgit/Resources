package com.velocityfrequentflyer.ms.controller;

import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.velocityfrequentflyer.ms.auth.RequestContext;
import com.velocityfrequentflyer.ms.dto.ErrorResponse;
import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import com.velocityfrequentflyer.ms.exception.MissingContextException;
import com.velocityfrequentflyer.ms.exception.MsException;
import com.velocityfrequentflyer.ms.exception.NotFoundException;
import com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper;
import com.velocityfrequentflyer.ms.exception.ServiceProviderException;
import com.velocityfrequentflyer.ms.exception.ValidationException;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@RequestMapping(value = "/${application.majorVersion}", produces = "application/json")
public abstract class BaseController {

  private static final Logger log = LoggerFactory.getLogger(BaseController.class);

  @Autowired private ServiceProviderErrorMapper serviceProviderErrorMapper;

  protected String getMemberId() {
    return RequestContext.getCurrent().getMemberId();
  }

  protected String getCorrelationId() {
    return RequestContext.getCurrent().getCorrelationId();
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({MissingContextException.class, ValidationException.class})
  @ResponseBody
  protected ErrorResponse handleBadRequest(HttpServletRequest req, MsException ex) {
    ErrorResponse res =
        new ErrorResponse.Builder()
            .title(ex.getMessage())
            .status(HttpStatus.BAD_REQUEST.value())
            .detail(ex.getCauseString())
            .type("loyalty:InvalidRequestError")
            .instance(req.getRequestURI())
            .mid(getCorrelationId())
            .build();

    log.error(res.toString());
    return res;
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({MethodArgumentNotValidException.class})
  @ResponseBody
  protected ErrorResponse handleBadRequest(
      HttpServletRequest req, MethodArgumentNotValidException ex) {
    ErrorResponse res =
        new ErrorResponse.Builder()
            .title("Validation of " + ex.getParameter().getParameterName() + " failed")
            .status(HttpStatus.BAD_REQUEST.value())
            .detail(ex.getMessage())
            .type("loyalty:InvalidRequestError")
            .instance(req.getRequestURI())
            .mid(getCorrelationId())
            .build();
    log.error(res.toString());
    return res;
  }

  @ResponseStatus(HttpStatus.NOT_FOUND)
  @ExceptionHandler({NotFoundException.class})
  @ResponseBody
  protected ErrorResponse handleNotFound(HttpServletRequest req, NotFoundException ex) {
    ErrorResponse res =
        new ErrorResponse.Builder()
            .title(ex.getMessage())
            .status(HttpStatus.NOT_FOUND.value())
            .detail(ex.getCauseString())
            .type("loyalty:NotFoundError")
            .instance(req.getRequestURI())
            .mid(getCorrelationId())
            .build();
    log.error(res.toString());
    return res;
  }

  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  @ExceptionHandler({AuthorizationException.class})
  @ResponseBody
  protected ErrorResponse handleAuthorizationException(
      HttpServletRequest req, AuthorizationException ex) {
    ErrorResponse res =
        new ErrorResponse.Builder()
            .title(ex.getMessage())
            .status(HttpStatus.valueOf(ex.getCode()).value())
            .detail(ex.getCauseString())
            .type("loyalty:AuthorizationError")
            .instance(req.getRequestURI())
            .mid(getCorrelationId())
            .build();
    log.warn(res.toString());
    return res;
  }

  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler({HystrixRuntimeException.class})
  @ResponseBody
  protected ErrorResponse handleHystrixError(HttpServletRequest req, HystrixRuntimeException ex) {
    log.error("Original exception ", ex);
    ErrorResponse res =
        new ErrorResponse.Builder()
            .title(ex.getMessage())
            .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .detail(ex.getFailureType().toString())
            .type("loyalty:ShortCircuitError")
            .instance(req.getRequestURI())
            .mid(getCorrelationId())
            .build();

    log.error(res.toString());
    return res;
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({ServiceProviderException.class})
  @ResponseBody
  protected ErrorResponse handleServiceProviderException(
      HttpServletRequest req, ServiceProviderException ex) {
    log.error("Request failure", ex);

    Map<String, String> errorDetails = serviceProviderErrorMapper.getErrorDetails(ex.getCode());

    ErrorResponse res =
        new ErrorResponse.Builder()
            .status(HttpStatus.BAD_REQUEST.value())
            .detail(errorDetails.getOrDefault("Detail", ex.getCauseString()))
            .title(errorDetails.getOrDefault("Title", ex.getMessage()))
            .type(errorDetails.getOrDefault("Type", "loyalty:GeneralApiError"))
            .instance(req.getRequestURI())
            .mid(getCorrelationId())
            .build();

    log.error(res.toString());
    return res;
  }
}
