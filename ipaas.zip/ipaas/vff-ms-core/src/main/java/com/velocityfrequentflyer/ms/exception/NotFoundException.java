package com.velocityfrequentflyer.ms.exception;

public class NotFoundException extends MsException {

  private static final long serialVersionUID = -8361708665672248182L;

  public NotFoundException(String message, String code, String cause) {
    super(message, code, cause);
  }
}
