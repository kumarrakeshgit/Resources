package com.velocityfrequentflyer.ms.dto;

import io.swagger.annotations.ApiModelProperty;

public class PointsChargesInfo {
  @ApiModelProperty(notes = "Velocity points required for trip", required = true)
  private String points;

  @ApiModelProperty(notes = "Trip cost", required = true)
  private String charges;

  @ApiModelProperty(notes = "Currency of charges")
  private String currency;

  public PointsChargesInfo() {}

  public PointsChargesInfo(String points, String charges, String currency) {
    this.points = points;
    this.charges = charges;
    this.currency = currency;
  }

  public String getPoints() {
    return points;
  }

  public void setPoints(String points) {
    this.points = points;
  }

  public String getCharges() {
    return charges;
  }

  public void setCharges(String charges) {
    this.charges = charges;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  @Override
  public String toString() {
    return "PointsChargesInfo [points="
        + points
        + ", charges="
        + charges
        + ", currency="
        + currency
        + "]";
  }
}
