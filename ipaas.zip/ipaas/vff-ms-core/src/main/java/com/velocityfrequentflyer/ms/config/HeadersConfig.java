package com.velocityfrequentflyer.ms.config;

import com.virginaustralia.model.schema.utility.ChoreographyType;
import com.virginaustralia.model.schema.utility.TransactionRequestHeaderType;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import org.oasis_open.docs.wss._2004._01.oasis_200401_wss_wssecurity_secext_1_0.AttributedString;
import org.oasis_open.docs.wss._2004._01.oasis_200401_wss_wssecurity_secext_1_0.PasswordString;
import org.oasis_open.docs.wss._2004._01.oasis_200401_wss_wssecurity_secext_1_0.SecurityHeaderType;
import org.oasis_open.docs.wss._2004._01.oasis_200401_wss_wssecurity_secext_1_0.UsernameTokenType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HeadersConfig {

  @Value("${VFF_ESB_USERNAME:user}")
  private String username;

  @Value("${VFF_ESB_ID:UsernameToken-1}")
  private String id;

  @Value("${vffuserpassword:password}")
  private String password;

  @Bean
  public SecurityHeaderType securityHeader() {
    SecurityHeaderType sh = new SecurityHeaderType();
    UsernameTokenType ut = new UsernameTokenType();
    AttributedString un = new AttributedString();

    un.setValue(username);
    ut.setUsername(un);
    ut.setId(id);
    PasswordString pass = new PasswordString();
    pass.setValue(password);

    QName qnamePassword =
        new QName(
            "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
            "Password");
    JAXBElement<PasswordString> jaxbPassword =
        new JAXBElement<>(qnamePassword, PasswordString.class, pass);
    ut.getAny().add(jaxbPassword);

    QName qname =
        new QName(
            "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
            "UsernameToken");
    JAXBElement<UsernameTokenType> jaxbUserName =
        new JAXBElement<>(qname, UsernameTokenType.class, ut);

    sh.getAny().add(jaxbUserName);

    return sh;
  }

  public static TransactionRequestHeaderType trxHeader(String correlationId) {
    TransactionRequestHeaderType trxHeader = new TransactionRequestHeaderType();

    QName qnameReqCtx =
        new QName("urn:www.virginaustralia.com:model:schema:utility", "RequestContext");
    ChoreographyType reqCtx = new ChoreographyType();
    JAXBElement<ChoreographyType> reqCtxJaxb =
        new JAXBElement<ChoreographyType>(qnameReqCtx, ChoreographyType.class, reqCtx);
    trxHeader.getContextExtension().add(reqCtxJaxb);

    QName qnameOrigReq =
        new QName("urn:www.virginaustralia.com:model:schema:utility", "OriginatingRequest");
    ChoreographyType origReq = new ChoreographyType();
    JAXBElement<ChoreographyType> origReqJaxb =
        new JAXBElement<ChoreographyType>(qnameOrigReq, ChoreographyType.class, origReq);
    reqCtx.getAny().add(origReqJaxb);

    QName qnameExternalId =
        new QName("urn:www.virginaustralia.com:model:schema:utility", "ExternalId");
    JAXBElement<String> externalIdJaxb =
        new JAXBElement<String>(qnameExternalId, String.class, correlationId);
    origReq.getAny().add(externalIdJaxb);

    QName qnameInternalId =
        new QName("urn:www.virginaustralia.com:model:schema:utility", "InternalId");
    JAXBElement<String> internalIdJaxb =
        new JAXBElement<String>(qnameInternalId, String.class, correlationId);
    origReq.getAny().add(internalIdJaxb);

    return trxHeader;
  }
}
