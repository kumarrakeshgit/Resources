package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class ErrorResponse {

  @ApiModelProperty(notes = "Error Status code")
  private Integer status;

  @ApiModelProperty(notes = "Error Title")
  private String title;

  @ApiModelProperty(notes = "Error Type")
  private String type;

  @ApiModelProperty(notes = "Error Detail")
  private String detail;

  @ApiModelProperty(notes = "Error Instance")
  private String instance;

  @ApiModelProperty(notes = "Error Correlation ID")
  private String mid;

  @Deprecated
  @ApiModelProperty(notes = "Error Message - Deprecated, please use title instead")
  private String message;

  @Deprecated
  @ApiModelProperty(notes = "Error Description - Deprecated, please use detail instead")
  private String description;

  public ErrorResponse() {}

  private ErrorResponse(Builder builder) {
    status = builder.status;
    title = builder.title;
    type = builder.type;
    detail = builder.detail;
    instance = builder.instance;
    mid = builder.mid;
    message = builder.title;
    description = builder.detail;
  }

  public Integer getStatus() {
    return status;
  }

  public String getTitle() {
    return title;
  }

  public String getType() {
    return type;
  }

  public String getDetail() {
    return detail;
  }

  public String getInstance() {
    return instance;
  }

  public String getMid() {
    return mid;
  }

  @Deprecated
  public String getMessage() {
    return message;
  }

  @Deprecated
  public String getDescription() {
    return description;
  }

  public static final class Builder {

    private Integer status;
    private String title;
    private String type;
    private String detail;
    private String instance;
    private String mid;

    public Builder() {}

    public Builder status(Integer val) {
      status = val;
      return this;
    }

    public Builder title(String val) {
      title = val;
      return this;
    }

    public Builder type(String val) {
      type = val;
      return this;
    }

    public Builder detail(String val) {
      detail = val;
      return this;
    }

    public Builder instance(String val) {
      instance = val;
      return this;
    }

    public Builder mid(String val) {
      mid = val;
      return this;
    }

    public ErrorResponse build() {
      return new ErrorResponse(this);
    }
  }

  @Override
  public String toString() {
    return "ErrorResponse{"
        + "status="
        + status
        + ", title='"
        + title
        + '\''
        + ", type='"
        + type
        + '\''
        + ", detail='"
        + detail
        + '\''
        + ", instance='"
        + instance
        + '\''
        + ", mid='"
        + mid
        + '\''
        + ", message='"
        + message
        + '\''
        + ", description='"
        + description
        + '\''
        + '}';
  }
}
