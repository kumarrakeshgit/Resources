package com.velocityfrequentflyer.ms.auth;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.oauth2.sdk.GeneralException;
import com.nimbusds.oauth2.sdk.id.Issuer;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import java.io.IOException;
import java.text.ParseException;
import java.util.concurrent.ExecutionException;

/**
 * Wraps the underlying IO-bound JWT static methods to assist with testing.
 *
 * @author somedude
 */
public class JwtDelegate {

  /**
   * Wraps {@link OIDCProviderMetadata#resolve}.
   *
   * @param url The {@link Issuer} URL.
   * @param issuerConnectionTimeoutMs The connection timeout in milliseconds.
   * @param issuerReadTimeoutMs The read timeout in milliseconds.
   * @return The fetched {@link OIDCProviderMetadata}.
   * @throws IOException when file operation fails
   * @throws GeneralException general jwt exception
   */
  public OIDCProviderMetadata fetchOicdProviderMetadata(
      final String url, final int issuerConnectionTimeoutMs, final int issuerReadTimeoutMs)
      throws IOException, GeneralException {

    return OIDCProviderMetadata.resolve(
        new Issuer(url), issuerConnectionTimeoutMs, issuerReadTimeoutMs);
  }

  /**
   * Wraps {@link JWKSet#load}.
   *
   * @param metadata The {@link OIDCProviderMetadata} of the associated {@link Issuer}.
   * @param jwksetConnectionTimeoutMs The connection timeout in milliseconds.
   * @param jwksetReadTimeoutMs The read timeout in milliseconds.
   * @param jwksetSizeLimitBytes The maximum accepted size of the fetched {@link JWKSet} in bytes.
   * @return The fetched {@link JWKSet}.
   * @throws IOException when file operation fails
   * @throws GeneralException general jwt exception
   * @throws ParseException when parsing jwt fails
   * @throws ExecutionException task execution fails
   */
  public JWKSet fetchJwkSet(
      final OIDCProviderMetadata metadata,
      final int jwksetConnectionTimeoutMs,
      final int jwksetReadTimeoutMs,
      final int jwksetSizeLimitBytes)
      throws IOException, ParseException, GeneralException, ExecutionException {

    return JWKSet.load(
        metadata.getJWKSetURI().toURL(),
        jwksetConnectionTimeoutMs,
        jwksetReadTimeoutMs,
        jwksetSizeLimitBytes);
  }

  /**
   * Wraps {@link SignedJWT#parse}.
   *
   * @param jwtString The base64 encoded signed JWT string to parse.
   * @return A parsed {@link SignedJWT}.
   * @throws ParseException when parsing jwt fails
   */
  public SignedJWT parseSignedJwt(String jwtString) throws ParseException {
    return SignedJWT.parse(jwtString);
  }
}
