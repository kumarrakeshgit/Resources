package com.velocityfrequentflyer.ms.mapping;

import java.time.LocalDate;
import javax.xml.datatype.XMLGregorianCalendar;
import ma.glasnost.orika.CustomConverter;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.metadata.Type;

/** @author Deniss Sudak */
public class XMLGregorianCalendarToLocalDateConverter
    extends CustomConverter<XMLGregorianCalendar, LocalDate> {

  @Override
  public LocalDate convert(
      XMLGregorianCalendar source,
      Type<? extends LocalDate> destinationType,
      MappingContext mappingContext) {
    return LocalDate.of(source.getYear(), source.getMonth(), source.getDay());
  }
}
