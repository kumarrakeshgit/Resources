package com.velocityfrequentflyer.ms.controller;

import com.velocityfrequentflyer.ms.dto.MsInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "Info Endpoint")
@RestController
public class MsInfoController {
  @Autowired private MsInfo info;

  @ApiOperation(
      value = "Get Microservice Information",
      notes = "This operation will return microservice service information",
      nickname = "getInfo")
  @RequestMapping(value = "/ms-info", method = RequestMethod.GET, produces = "application/json")
  public MsInfo getInfo() {
    return info;
  }
}
