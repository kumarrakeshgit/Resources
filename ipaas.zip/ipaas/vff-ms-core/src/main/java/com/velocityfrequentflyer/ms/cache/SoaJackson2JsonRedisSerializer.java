package com.velocityfrequentflyer.ms.cache;

import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import java.io.IOException;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.springframework.cache.support.NullValue;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.util.StringUtils;

/** @author Deniss Sudak */
public class SoaJackson2JsonRedisSerializer extends GenericJackson2JsonRedisSerializer {

  public SoaJackson2JsonRedisSerializer() {
    super(new SoaObjectMapper());
  }

  private static class SoaObjectMapper extends ObjectMapper {

    private SoaObjectMapper() {
      SimpleModule xmlGregorianCalendarModule = new SimpleModule("XMLGregorianCalendar Module");
      xmlGregorianCalendarModule.addSerializer(
          new StdSerializer<XMLGregorianCalendar>(XMLGregorianCalendar.class) {
            @Override
            public void serialize(
                XMLGregorianCalendar value, JsonGenerator gen, SerializerProvider serializers)
                throws IOException {
              gen.writeStringField(
                  "value", Long.toString(value.toGregorianCalendar().getTimeInMillis()));
            }

            @Override
            public void serializeWithType(
                XMLGregorianCalendar value,
                JsonGenerator gen,
                SerializerProvider serializers,
                TypeSerializer typeSer)
                throws IOException {
              typeSer.writeTypePrefixForObject(
                  value, gen, javax.xml.datatype.XMLGregorianCalendar.class);
              serialize(value, gen, serializers);
              typeSer.writeTypeSuffixForObject(value, gen);
            }
          });

      xmlGregorianCalendarModule.addDeserializer(
          XMLGregorianCalendar.class,
          new StdDeserializer<XMLGregorianCalendar>(XMLGregorianCalendar.class) {

            @Override
            public XMLGregorianCalendar deserialize(JsonParser p, DeserializationContext ctxt)
                throws IOException {
              try {
                JsonNode node = p.getCodec().readTree(p);
                GregorianCalendar cal = new GregorianCalendar();
                cal.setTime(new Date(Long.parseLong(node.get("value").asText())));

                return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
              } catch (DatatypeConfigurationException e) {
                throw new IOException(e);
              }
            }

            @Override
            public Object deserializeWithType(
                JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
                throws IOException {
              return deserialize(p, ctxt);
            }
          });

      registerModule(xmlGregorianCalendarModule);
      registerModule(new SimpleModule().addSerializer(new NullValueSerializer(null)));
      registerModule(new ParameterNamesModule());
      registerModule(new Jdk8Module());
      registerModule(new JavaTimeModule());
      enableDefaultTyping(DefaultTyping.NON_FINAL, As.PROPERTY);

      configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    }
  }

  /** copy from {@link GenericJackson2JsonRedisSerializer} */
  private static class NullValueSerializer extends StdSerializer<NullValue> {

    private final String classIdentifier;

    NullValueSerializer(String classIdentifier) {
      super(NullValue.class);
      this.classIdentifier = StringUtils.hasText(classIdentifier) ? classIdentifier : "@class";
    }

    @Override
    public void serialize(NullValue value, JsonGenerator jgen, SerializerProvider provider)
        throws IOException {

      jgen.writeStartObject();
      jgen.writeStringField(classIdentifier, NullValue.class.getName());
      jgen.writeEndObject();
    }
  }
}
