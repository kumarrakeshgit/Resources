package com.velocityfrequentflyer.ms.service;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig.TableNameOverride;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import javax.annotation.PostConstruct;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

public class DynamoDBBaseService {

  private static final Logger log = LoggerFactory.getLogger(DynamoDBBaseService.class);

  protected AmazonDynamoDB dynClient;
  protected DynamoDBMapper dynamoDBMapper;
  protected DynamoDB dynamoDB;

  @Value("${VFF_DYNAMODB_ENDPOINT_URL:https://dynamodb.ap-southeast-2.amazonaws.com}")
  protected String dynamoEndpoint;

  @Value("${ENVIRONMENT_NAME}")
  protected String envName;

  protected String tableName;

  private String tableNameBase;

  public DynamoDBBaseService(String tableNameBase) {
    this.tableNameBase = tableNameBase;
  }

  public DynamoDBMapperConfig dynamoDBMapperConfig() {
    DynamoDBMapperConfig.Builder builder = new DynamoDBMapperConfig.Builder();
    builder.setTableNameOverride(TableNameOverride.withTableNameReplacement(tableName));
    return builder.build();
  }

  @PostConstruct
  public void init() {
    log.debug("dynamoEndpoint=" + dynamoEndpoint);
    dynClient =
        AmazonDynamoDBClientBuilder.standard()
            .withEndpointConfiguration(
                new AwsClientBuilder.EndpointConfiguration(
                    dynamoEndpoint, Regions.AP_SOUTHEAST_2.getName()))
            .build();
    tableName = tableNameBase + (StringUtils.isNotBlank(envName) ? "_" + envName : "");
    log.info("Table name: " + tableName);
    dynamoDBMapper = new DynamoDBMapper(dynClient, dynamoDBMapperConfig());
    dynamoDB = new DynamoDB(dynClient);
  }
}
