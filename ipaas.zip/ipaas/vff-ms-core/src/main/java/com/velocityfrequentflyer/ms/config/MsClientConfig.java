package com.velocityfrequentflyer.ms.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class MsClientConfig {

  @Value("${MS_CLIENT_TIMEOUT:40000}")
  private int timeout;

  @Bean
  public RestTemplate getClientHttpRequestFactory() {
    SkipSslVerificationHttpRequestFactory requestFactory =
        new SkipSslVerificationHttpRequestFactory();

    requestFactory.setConnectTimeout(timeout);
    requestFactory.setReadTimeout(timeout);

    return new RestTemplate(requestFactory);
  }
}
