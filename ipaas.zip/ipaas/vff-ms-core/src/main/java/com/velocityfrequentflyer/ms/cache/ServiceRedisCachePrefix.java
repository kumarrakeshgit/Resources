package com.velocityfrequentflyer.ms.cache;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.cache.RedisCachePrefix;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

@Component
public class ServiceRedisCachePrefix implements RedisCachePrefix {

  private final RedisSerializer<String> serializer = new StringRedisSerializer();

  @Value("${application.name}")
  private String servicePrefix;

  @Override
  public byte[] prefix(String cacheName) {
    return serializer.serialize(servicePrefix.concat(":").concat(cacheName).concat(":"));
  }
}
