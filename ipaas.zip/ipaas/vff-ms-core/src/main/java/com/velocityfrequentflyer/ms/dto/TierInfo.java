package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TierInfo {
  @ApiModelProperty(
      notes =
          "Tier Level. Can be: R for Red, S for Silver, G for Gold and P for Platinum, V for VIP. If empty, denotes that there is not applicable tier for upgrade or downgrade")
  private String tierLevel;

  @ApiModelProperty(
      notes =
          "Sub Tier Level. Examples are: C for Corporate, S for Standard, E for Executive. If empty, denotes that there is not applicable tier for upgrade or downgrade")
  private String subTierLevel;

  @ApiModelProperty(
      notes =
          "Credits left to next level or maintain current one. This can be 0 if there is no points required to maintain or to upgrade")
  private Integer creditsLeft;

  @ApiModelProperty(
      notes =
          "Sectors left to next level or maintain current one. This can be 0 if there is no points required to maintain or to upgrade")
  private Integer sectorsLeft;

  @ApiModelProperty(
      notes = "Credits required to maintain or upgrade, 0 if not upgradeable or downgradable")
  private Integer creditsRequired;

  @ApiModelProperty(
      notes = "Sectors required to maintain or upgrade, 0 if not upgradeable or downgradable")
  private Integer sectorsRequired;

  public String getTierLevel() {
    return tierLevel;
  }

  public void setTierLevel(String tierLevel) {
    this.tierLevel = tierLevel == null ? tierLevel : tierLevel.toUpperCase();
  }

  public String getSubTierLevel() {
    return subTierLevel;
  }

  public void setSubTierLevel(String subTierLevel) {
    this.subTierLevel = subTierLevel == null ? null : subTierLevel.toUpperCase();
  }

  public Integer getCreditsLeft() {
    return creditsLeft;
  }

  public void setCreditsLeft(Integer pointsLeft) {
    this.creditsLeft = pointsLeft;
  }

  public Integer getSectorsLeft() {
    return sectorsLeft;
  }

  public void setSectorsLeft(Integer sectorsLeft) {
    this.sectorsLeft = sectorsLeft;
  }

  public Integer getCreditsRequired() {
    return creditsRequired;
  }

  public void setCreditsRequired(Integer creditsRequired) {
    this.creditsRequired = creditsRequired;
  }

  public Integer getSectorsRequired() {
    return sectorsRequired;
  }

  public void setSectorsRequired(Integer sectorsRequired) {
    this.sectorsRequired = sectorsRequired;
  }

  public String retrieveTierCode() {
    String subTier = this.subTierLevel == null ? "" : this.subTierLevel.toUpperCase();
    String tier = this.tierLevel == null ? "" : this.tierLevel.toUpperCase();
    return new StringBuffer(subTier).append(tier).toString();
  }

  @Override
  public String toString() {
    return "TierInfo [tierLevel="
        + tierLevel
        + ", subTierLevel="
        + subTierLevel
        + ", creditsLeft="
        + creditsLeft
        + ", sectorsLeft="
        + sectorsLeft
        + ", creditsRequired="
        + creditsRequired
        + ", sectorsRequired="
        + sectorsRequired
        + "]";
  }
}
