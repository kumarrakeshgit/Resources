package com.velocityfrequentflyer.ms.s3;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for processing files in S3.
 *
 * <p>Supported Methods - Download - Move files (delete original file)
 *
 * @author benshi
 */
public class S3FileProcessor {

  private static final Logger LOG = LoggerFactory.getLogger(S3FileProcessor.class);

  private AmazonS3 amazonS3;

  /**
   * Default Constructor fo the {@link S3FileProcessor}.
   *
   * @param amazonS3 - required S3 client connection object to perform relevant S3 operation
   */
  public S3FileProcessor(AmazonS3 amazonS3) {
    this.amazonS3 = amazonS3;
  }

  /**
   * Method for downloading S3Object to temporary {@link File} and return back to user.
   *
   * @param bucketName - name of bucket
   * @param fileName - key of the object (support subfolders)
   * @return {@link File} - file handle
   * @throws IOException - when temporary file could not be created
   */
  public File downloadFileFromS3(String bucketName, String fileName) throws IOException {
    return downloadFileFromS3(bucketName, fileName, null);
  }

  /**
   * Base method for download S3Object into a temporary {@link File} and return handle back to user.
   * Correctly sets the file extension for temp file.
   *
   * @param bucketName - name of bucket
   * @param fileName - key of the object (support subfolders)
   * @param tempFileExt - temporary file extention, if required
   * @return {@link File} - file handle
   * @throws IOException - when temporary file could not be created
   */
  public File downloadFileFromS3(String bucketName, String fileName, String tempFileExt)
      throws IOException {
    File tempFile = Files.createTempFile(null, tempFileExt).toFile();
    tempFile.deleteOnExit();
    GetObjectRequest request = new GetObjectRequest(bucketName, fileName);
    ObjectMetadata object = amazonS3.getObject(request, tempFile);

    LOG.debug("Temp File Location: {}" + tempFile.getCanonicalPath());
    LOG.debug("S3 Object Meta" + object.getRawMetadata().toString());

    return tempFile;
  }

  /**
   * Method for moving file within bucket
   *
   * @param bucketName - name of the bucket
   * @param srcFileName - source file name
   * @param destFileName - destination file name
   * @return {@link Boolean} true on success, false of exception
   */
  public boolean moveFileWithinBucket(String bucketName, String srcFileName, String destFileName) {
    return moveFileBetweenBuckets(bucketName, srcFileName, bucketName, destFileName);
  }

  /**
   * Method for moving file between buckets. TODO: delete source file removed for the time being
   * until infrastructure can support deleteObject permission on S3
   *
   * @param srcBucketName - source bucket name
   * @param srcFileName - source file name
   * @param destBucketName - destination bucket name
   * @param destFileName - destination bucket name
   * @return {@link Boolean} true on success, false of exception
   */
  public boolean moveFileBetweenBuckets(
      String srcBucketName, String srcFileName, String destBucketName, String destFileName) {
    try {
      amazonS3.copyObject(srcBucketName, srcFileName, destBucketName, destFileName);
      return true;
    } catch (AmazonServiceException e) {
      LOG.error("Error moving file {}", e);
      return false;
    }
  }
}
