package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigInteger;
import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountStatus {
  @ApiModelProperty(notes = "Loyalty Membership ID")
  private String loyaltyMembershipID;

  @ApiModelProperty(notes = "Current Points Balance")
  private BigInteger currentPointsBalance;

  @ApiModelProperty(notes = "Current Points Balance Expire Date in ISO-8601 format")
  private LocalDate currentPointsBalanceExpiryDate;

  @ApiModelProperty(notes = "Whether the Points Balance is nearing the Expire Date")
  private boolean nearingExpiryDate;

  @ApiModelProperty(notes = "Status Credits Balance")
  private BigInteger statusCreditsBalance;

  @ApiModelProperty(notes = "Status Sectors Balance")
  private BigInteger statusSectorsBalance;

  @ApiModelProperty(notes = "Current Benefit Period Status Credits Balance")
  private BigInteger benefitPeriodStatusCreditsBalance;

  @ApiModelProperty(notes = "Current Benefit Period Status Sectors Balance")
  private BigInteger benefitPeriodStatusSectorsBalance;

  @ApiModelProperty(notes = "Current Benefit Period Expiry Date in ISO-8601 format")
  private LocalDate benefitPeriodExpiryDate;

  @ApiModelProperty(notes = "Update Date in ISO-8601 format")
  private LocalDate updateDate;

  @ApiModelProperty(notes = "Current Tier Info")
  private TierInfo currentTierInfo;

  @ApiModelProperty(notes = "Downgrade Tier Info")
  private TierInfo downgradeTierInfo;

  @ApiModelProperty(notes = "Upgrade Tier Info")
  private TierInfo upgradeTierInfo;

  @ApiModelProperty(notes = "Account Status Code. Can be: ACTIVE or NOT ACTIVE")
  private String accountStatusCode;

  @ApiModelProperty(notes = "Qual Period End in ISO-8601 format")
  private LocalDate qualPeriodEnd;

  @ApiModelProperty(notes = "Flag that indicates if a member is during the review period")
  private Boolean underReview;

  @ApiModelProperty(notes = "ValidityPeriod in months for the current tier")
  private BigInteger validityPeriod;

  public String getLoyaltyMembershipID() {
    return loyaltyMembershipID;
  }

  public void setLoyaltyMembershipID(String loyaltyMembershipID) {
    this.loyaltyMembershipID = loyaltyMembershipID;
  }

  public void setCurrentPointsBalance(BigInteger currentPointsBalance) {
    this.currentPointsBalance = currentPointsBalance;
  }

  public BigInteger getCurrentPointsBalance() {
    return currentPointsBalance;
  }

  public void setCurrentPointsBalanceExpiryDate(LocalDate currentPointsBalanceExpireDate) {
    this.currentPointsBalanceExpiryDate = currentPointsBalanceExpireDate;
  }

  public LocalDate getCurrentPointsBalanceExpiryDate() {
    return currentPointsBalanceExpiryDate;
  }

  public boolean isNearingExpiryDate() {
    return nearingExpiryDate;
  }

  public void setNearingExpiryDate(boolean nearingExpiryDate) {
    this.nearingExpiryDate = nearingExpiryDate;
  }

  public void setStatusCreditsBalance(BigInteger statusCreditsBalance) {
    this.statusCreditsBalance = statusCreditsBalance;
  }

  public BigInteger getStatusCreditsBalance() {
    return statusCreditsBalance;
  }

  public void setStatusSectorsBalance(BigInteger statusSectorsBalance) {
    this.statusSectorsBalance = statusSectorsBalance;
  }

  public BigInteger getStatusSectorsBalance() {
    return statusSectorsBalance;
  }

  public BigInteger getBenefitPeriodStatusCreditsBalance() {
    return benefitPeriodStatusCreditsBalance;
  }

  public void setBenefitPeriodStatusCreditsBalance(BigInteger benefitStatusCreditsBalance) {
    this.benefitPeriodStatusCreditsBalance = benefitStatusCreditsBalance;
  }

  public BigInteger getBenefitPeriodStatusSectorsBalance() {
    return benefitPeriodStatusSectorsBalance;
  }

  public void setBenefitPeriodStatusSectorsBalance(BigInteger benefitStatusSectorsBalance) {
    this.benefitPeriodStatusSectorsBalance = benefitStatusSectorsBalance;
  }

  public LocalDate getBenefitPeriodExpiryDate() {
    return benefitPeriodExpiryDate;
  }

  public void setBenefitPeriodExpiryDate(LocalDate benefitExpiryDate) {
    this.benefitPeriodExpiryDate = benefitExpiryDate;
  }

  public void setUpdateDate(LocalDate updateDate) {
    this.updateDate = updateDate;
  }

  public LocalDate getUpdateDate() {
    return updateDate;
  }

  public void setCurrentTierInfo(TierInfo tierCode) {
    this.currentTierInfo = tierCode;
  }

  public TierInfo getCurrentTierInfo() {
    return currentTierInfo;
  }

  public void setDowngradeTierInfo(TierInfo downgradeTierCode) {
    this.downgradeTierInfo = downgradeTierCode;
  }

  public TierInfo getDowngradeTierInfo() {
    return downgradeTierInfo;
  }

  public TierInfo getUpgradeTierInfo() {
    return upgradeTierInfo;
  }

  public void setUpgradeTierInfo(TierInfo upgradeTierInfo) {
    this.upgradeTierInfo = upgradeTierInfo;
  }

  public String getAccountStatusCode() {
    return accountStatusCode;
  }

  public void setAccountStatusCode(String accountStatusCode) {
    this.accountStatusCode = accountStatusCode;
  }

  public LocalDate getQualPeriodEnd() {
    return qualPeriodEnd;
  }

  public void setQualPeriodEnd(LocalDate qualPeriodEnd) {
    this.qualPeriodEnd = qualPeriodEnd;
  }

  public Boolean getUnderReview() {
    return underReview;
  }

  public void setUnderReview(Boolean underReview) {
    this.underReview = underReview;
  }

  public BigInteger getValidityPeriod() {
    return validityPeriod;
  }

  public void setValidityPeriod(BigInteger validityPeriod) {
    this.validityPeriod = validityPeriod;
  }

  @Override
  public String toString() {
    return "AccountStatus [loyaltyMembershipID="
        + loyaltyMembershipID
        + ", currentPointsBalance="
        + currentPointsBalance
        + ", currentPointsBalanceExpiryDate="
        + currentPointsBalanceExpiryDate
        + ", nearingExpiryDate="
        + nearingExpiryDate
        + ", statusCreditsBalance="
        + statusCreditsBalance
        + ", statusSectorsBalance="
        + statusSectorsBalance
        + ", benefitPeriodStatusCreditsBalance="
        + benefitPeriodStatusCreditsBalance
        + ", benefitPeriodStatusSectorsBalance="
        + benefitPeriodStatusSectorsBalance
        + ", benefitPeriodExpiryDate="
        + benefitPeriodExpiryDate
        + ", underReview="
        + underReview
        + ", updateDate="
        + updateDate
        + ", currentTierInfo="
        + currentTierInfo
        + ", downgradeTierInfo="
        + downgradeTierInfo
        + ", upgradeTierInfo="
        + upgradeTierInfo
        + ", accountStatusCode="
        + accountStatusCode
        + ", qualPeriodEnd="
        + qualPeriodEnd
        + ", validityPeriod="
        + validityPeriod
        + "]";
  }
}
