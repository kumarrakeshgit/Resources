package com.velocityfrequentflyer.ms.exception;

public class MissingContextException extends MsException {
  private static final long serialVersionUID = -8778102431077277139L;

  public static final String EXTERNAL_MESSAGE = "Request context missing";

  public MissingContextException(String message, String code, String cause) {
    super(message, code, cause);
  }
}
