package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@Component
public class MsInfo {
  @ApiModelProperty(notes = "API Name")
  @Value("${application.name}")
  private String name;

  @ApiModelProperty(notes = "API Description")
  @Value("${application.description}")
  private String description;

  @ApiModelProperty(notes = "Environment Number")
  @Value("${ENVIRONMENT_NUMBER}")
  private String environmentNumber;

  @ApiModelProperty(notes = "Environment Name")
  @Value("${ENVIRONMENT_NAME}")
  private String environmentName;

  @ApiModelProperty(notes = "Region")
  @Value("${AWS_REGION}")
  private String region;

  @ApiModelProperty(notes = "Account ID")
  @Value("${AWS_ACCOUNT_ID}")
  private String accountId;

  @ApiModelProperty(notes = "Build")
  @Value("${application.build}")
  private String build;

  @ApiModelProperty(notes = "Build Timestamp")
  @Value("${application.build.timestamp}")
  private String timestamp;

  @ApiModelProperty(notes = "Version")
  @Value("${application.version}")
  private String version;

  @ApiModelProperty(notes = "Git SHA of commit build made of")
  @Value("${GIT_COMMIT}")
  private String commit;

  @ApiModelProperty(notes = "GIT Branch build made of")
  @Value("${GIT_BRANCH}")
  private String branch;

  @ApiModelProperty(notes = "GIT Repo URL")
  @Value("${GIT_URL}")
  private String url;

  public String getBuild() {
    return build;
  }

  public String getTimestamp() {
    return timestamp;
  }

  public String getVersion() {
    return version;
  }

  public String getEnvironmentNumber() {
    return environmentNumber;
  }

  public String getEnvironmentName() {
    return environmentName;
  }

  public String getRegion() {
    return region;
  }

  public String getAccountId() {
    return accountId;
  }

  public String getCommit() {
    return commit;
  }

  public String getBranch() {
    return branch;
  }

  public String getUrl() {
    return url;
  }

  public String getName() {
    return name;
  }

  public String getDescription() {
    return description;
  }
}
