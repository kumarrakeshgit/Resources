package com.velocityfrequentflyer.ms.exception;

import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.CODE;
import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.DETAIL;
import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.TITLE;
import static com.velocityfrequentflyer.ms.exception.ServiceProviderErrorMapper.ErrorCodeField.TYPE;
import static org.apache.commons.lang3.StringEscapeUtils.escapeJson;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.AbstractMap.SimpleEntry;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

@Component
public class ServiceProviderErrorMapper {

  private static final Logger LOG = LoggerFactory.getLogger(ServiceProviderErrorMapper.class);

  private static final String ERROR_FILE_NAME = "SOAErrorCodes.txt";

  private Map<String, Map<String, String>> errorMap;

  public ServiceProviderErrorMapper() throws IOException {
    Resource resource = new ClassPathResource(ERROR_FILE_NAME);
    InputStreamResource streamResource = new InputStreamResource(resource.getInputStream());

    Iterable<CSVRecord> records =
        CSVFormat.DEFAULT
            .withDelimiter('|')
            .withFirstRecordAsHeader()
            .parse(new InputStreamReader(streamResource.getInputStream()));

    LOG.info("Loading SOAErrorCodes..");

    HashMap<String, Map<String, String>> tempMap = new HashMap<>();
    records.forEach(
        record -> {
          Map<String, String> map =
              Collections.unmodifiableMap(
                  Stream.of(
                          new SimpleEntry<>(
                              TITLE.getValue(), escapeJson(record.get(TITLE.getValue()))),
                          new SimpleEntry<>(
                              TYPE.getValue(), escapeJson(record.get(TYPE.getValue()))),
                          new SimpleEntry<>(
                              DETAIL.getValue(), escapeJson(record.get(DETAIL.getValue()))))
                      .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue)));
          tempMap.putIfAbsent(record.get(CODE.getValue()), map);
        });
    errorMap = Collections.unmodifiableMap(tempMap);
  }

  public Map<String, String> getErrorDetails(String errorCode) {
    return errorMap.getOrDefault(errorCode, Collections.emptyMap());
  }

  public Map<String, Map<String, String>> getErrorMap() {
    return errorMap;
  }

  public enum ErrorCodeField {
    CODE("Code"),
    TITLE("Title"),
    DETAIL("Detail"),
    TYPE("Type");

    private String value;

    ErrorCodeField(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }
  }
}
