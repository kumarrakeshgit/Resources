package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;

public class Airport {

  @ApiModelProperty(notes = "Airport code ISO", required = true, example = "SYD")
  private String code;

  @ApiModelProperty(notes = "Airport name", required = true, example = "Kingsford Smith Intl.")
  private String name;

  @JsonIgnore private String oceanContinent;

  @ApiModelProperty(notes = "Airport country", required = true, example = "Australia")
  private String country;

  @ApiModelProperty(required = true, example = "Sydney")
  private String city;

  @ApiModelProperty(
      notes = "Airport geo location coordinates",
      required = true,
      example = "49.210833d")
  private Double latitude;

  @ApiModelProperty(
      notes = "Airport geo location coordinates",
      required = true,
      example = "-57.391388d")
  private Double longitude;

  @ApiModelProperty(notes = "Default (390x210) Image URL", required = true)
  private String image;

  @JsonIgnore private String tags;

  public Airport() {}

  public Airport(
      String code,
      String name,
      String oceanContinent,
      String country,
      String city,
      Double latitude,
      Double longitude,
      String image,
      String tags) {
    this.code = code;
    this.name = name;
    this.oceanContinent = oceanContinent;
    this.country = country;
    this.city = city;
    this.latitude = latitude;
    this.longitude = longitude;
    this.image = image;
    this.tags = tags;
  }

  public String getCode() {
    return code;
  }

  public String getName() {
    return name;
  }

  public String getOceanContinent() {
    return oceanContinent;
  }

  public String getCountry() {
    return country;
  }

  public String getCity() {
    return city;
  }

  public Double getLatitude() {
    return latitude;
  }

  public Double getLongitude() {
    return longitude;
  }

  public String getImage() {
    return image;
  }

  public String getTags() {
    return tags;
  }

  @Override
  public String toString() {
    return "Airport [code="
        + code
        + ", name="
        + name
        + ", oceanContinent="
        + oceanContinent
        + ", country="
        + country
        + ", city="
        + city
        + ", latitude="
        + latitude
        + ", longitude="
        + longitude
        + ", image="
        + image
        + ", tags="
        + tags
        + "]";
  }
}
