package com.velocityfrequentflyer.ms.auth;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.oauth2.sdk.GeneralException;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Jwt {

  private JwtDelegate jwtDelegate = new JwtDelegate();

  @Value("${JWT_ISSUER_URI:https://accounts-test.velocityfrequentflyer.com/auth/realms/velocity}")
  private String issuerUri;

  @Value("${jwt-auth.issuer-connection-timeout:10000}")
  private int issuerConnectionTimeoutMs;

  @Value("${jwt-auth.issuer-read-timeout:10000}")
  private int issuerReadTimeoutMs;

  @Value("${jwt-auth.keyset-connection-timeout:10000}")
  private int jwksetConnectionTimeoutMs;

  @Value("${jwt-auth.keyset-read-timeout:10000}")
  private int jwksetReadTimeoutMs;

  @Value("${jwt-auth.keyset-size-limit:1048576}")
  private int jwksetSizeLimitBytes;

  @Value("${jwt-auth.member-id-claim-key:preferred_username}")
  private String memberIdClaimKey = "preferred_username";

  private Map<String, JWKSet> keysetCache = new HashMap<String, JWKSet>();

  private static final Logger log = LoggerFactory.getLogger(Jwt.class);

  /**
   * Extracts the full claims set from the provided signed JWT, after successful parsing and
   * validation.
   *
   * @param jwtString A base64 encoded, signed JWT string.
   * @return The claims set extracted from the JWT.
   */
  public JWTClaimsSet fetchVerifiedClaimSet(final String jwtString) throws AuthorizationException {
    try {
      SignedJWT jwt = jwtDelegate.parseSignedJwt(jwtString);
      if (jwt.getJWTClaimsSet().getExpirationTime().before(new Date())) {
        throw new AuthorizationException("JWT has expired");
      }

      JWKSet jwkSet = fetchJwkSet(issuerUri);
      String kid = jwt.getHeader().getKeyID();

      List<JWK> keys;
      if (kid == null) {
        keys = jwkSet.getKeys();
      } else {
        JWK key = jwkSet.getKeyByKeyId(kid);
        keys = key == null ? Collections.emptyList() : Collections.singletonList(key);
      }

      if (!verifyJwt(jwt, keys)) {
        throw new AuthorizationException("Failed to verify JWT");
      }
      return jwt.getJWTClaimsSet();

    } catch (Throwable e) {
      log.error("Unexpected error while validating JWT ", e);
      throw new AuthorizationException("Unexpected error while validating JWT", e);
    }
  }

  /**
   * Extracts the Velocity member ID from the provided signed JWT, after successful parsing and
   * validation.
   *
   * @param jwtString A base64 encoded, signed JWT string.
   * @return The Velocity member ID extracted from the JWT.
   */
  public String fetchVerifiedMemberId(final String jwtString) throws AuthorizationException {
    Object memberIdClaim = fetchVerifiedClaimSet(jwtString).getClaim(memberIdClaimKey);
    if (!(memberIdClaim instanceof String)) {
      throw new AuthorizationException("Missing or invalid member ID claim in JWT");
    }
    return (String) memberIdClaim;
  }

  private boolean verifyJwt(final SignedJWT jwt, final List<JWK> keys)
      throws JOSEException, ParseException {
    for (JWK key : keys) {
      if (key.getAlgorithm().equals(JWSAlgorithm.RS256)) {
        JWSVerifier verifier = new RSASSAVerifier((RSAKey) key);
        if (jwt.verify(verifier)) {
          return true;
        }
      }
    }
    return false;
  }

  private JWKSet fetchJwkSet(final String url)
      throws IOException, ParseException, GeneralException, ExecutionException {
    JWKSet value = keysetCache.get(url);
    if (value == null) {
      OIDCProviderMetadata metadata =
          jwtDelegate.fetchOicdProviderMetadata(
              url, issuerConnectionTimeoutMs, issuerReadTimeoutMs);

      value =
          jwtDelegate.fetchJwkSet(
              metadata, jwksetConnectionTimeoutMs, jwksetReadTimeoutMs, jwksetSizeLimitBytes);

      keysetCache.put(url, value);
    }

    return value;
  }

  public void setIssuerUri(String issuerUri) {
    this.issuerUri = issuerUri;
  }

  public void setIssuerConnectionTimeoutMs(int issuerConnectionTimeoutMs) {
    this.issuerConnectionTimeoutMs = issuerConnectionTimeoutMs;
  }

  public void setIssuerReadTimeoutMs(int issuerReadTimeoutMs) {
    this.issuerReadTimeoutMs = issuerReadTimeoutMs;
  }

  public void setJwksetConnectionTimeoutMs(int jwksetConnectionTimeoutMs) {
    this.jwksetConnectionTimeoutMs = jwksetConnectionTimeoutMs;
  }

  public void setJwksetReadTimeoutMs(int jwksetReadTimeoutMs) {
    this.jwksetReadTimeoutMs = jwksetReadTimeoutMs;
  }

  public void setJwksetSizeLimitBytes(int jwksetSizeLimitBytes) {
    this.jwksetSizeLimitBytes = jwksetSizeLimitBytes;
  }

  public void setMemberIdClaimKey(String memberIdClaimKey) {
    this.memberIdClaimKey = memberIdClaimKey;
  }

  public void setJwtDelegate(JwtDelegate jwtDelegate) {
    this.jwtDelegate = jwtDelegate;
  }
}
