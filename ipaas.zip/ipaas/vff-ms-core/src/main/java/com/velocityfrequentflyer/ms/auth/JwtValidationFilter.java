package com.velocityfrequentflyer.ms.auth;

import static com.google.common.collect.Sets.newHashSet;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.isNotBlank;

import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import java.io.IOException;
import java.util.Set;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

/**
 * @author Alex Kuchar
 * @author Deniss Sudak
 */
@WebFilter
public class JwtValidationFilter implements Filter {

  @Value("${jwt-auth.correlation-id-header:X-Correlation-ID}")
  private String correlationIdHeader;

  @Value("${jwt-auth.correlation-id-mdc-tag:CORRELATION_ID}")
  private String correlationIdMdcTag;

  @Value("${jwt-auth.jwt-id-token-header:X-JWT-ID-Token}")
  private String jwtIdTokenHeader;

  @Value("${jwt-auth.memberIdMdcTag:MEMBER_ID}")
  private String memberIdMdcTag;

  @Value("${jwt-auth.test-member-id:}")
  private String testMemberId;

  @Value("${jwt-auth.test-correlation-id:}")
  private String testCorrelationId;

  @Value("${application.majorVersion}")
  private String majorVersion;

  @Value("${application.secure-ms-prefixes}")
  private String secureMsPrefixes;

  @Autowired private Jwt jwt;

  private Set<String> protectedPathPrefixes;

  @Override
  public void init(FilterConfig filterConfig) {
    protectedPathPrefixes = newHashSet();
    for (String securePrefix : secureMsPrefixes.split(",")) {
      protectedPathPrefixes.add(("/" + majorVersion + "/" + securePrefix.trim()).toLowerCase());
    }
  }

  /**
   * Extracts a Correlation ID and Velocity Member ID from the incoming request and attached to the
   * {@link RequestContext} associated with the current request. MDC tags will also be created to
   * allow the inclusion of the Correlation ID and Member ID in any logging that takes place during
   * the life of the request.
   */
  @Override
  public void doFilter(
      ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
      throws IOException, ServletException {
    HttpServletRequest request = (HttpServletRequest) servletRequest;
    HttpServletResponse response = (HttpServletResponse) servletResponse;

    String correlationId =
        isBlank(testCorrelationId) ? request.getHeader(correlationIdHeader) : testCorrelationId;

    MDC.put(correlationIdMdcTag, correlationId);

    String memberId = null;
    if (isBlank(testMemberId)) {
      String jwtString = request.getHeader(jwtIdTokenHeader);
      if (isNotBlank(jwtString)) {
        memberId = jwt.fetchVerifiedMemberId(jwtString);
      } else if (isProtectedResources(request.getRequestURI())) {
        throw new AuthorizationException("Missing JWT ID Token Header");
      }
    } else {
      memberId = testMemberId;
    }

    MDC.put(memberIdMdcTag, memberId);

    RequestContext.setCurrent(
        new RequestContext(memberId, correlationId, request.getHeader(jwtIdTokenHeader)));
    filterChain.doFilter(request, response);
  }

  private boolean isProtectedResources(String uri) {
    for (String protectedPathPrefixes : protectedPathPrefixes) {
      if (uri.toLowerCase().startsWith(protectedPathPrefixes)) {
        return true;
      }
    }

    return false;
  }

  @Override
  public void destroy() {
    RequestContext.clearCurrent();
  }

  public String getCorrelationIdHeader() {
    return correlationIdHeader;
  }

  public String getJwtIdTokenHeader() {
    return jwtIdTokenHeader;
  }

  public void setCorrelationIdHeader(String correlationIdHeader) {
    this.correlationIdHeader = correlationIdHeader;
  }

  public void setCorrelationIdMdcTag(String correlationIdMdcTag) {
    this.correlationIdMdcTag = correlationIdMdcTag;
  }

  public void setJwtIdTokenHeader(String jwtIdTokenHeader) {
    this.jwtIdTokenHeader = jwtIdTokenHeader;
  }

  public void setMemberIdMdcTag(String memberIdMdcTag) {
    this.memberIdMdcTag = memberIdMdcTag;
  }

  public void setJwt(Jwt jwt) {
    this.jwt = jwt;
  }

  public void setTestMemberId(String testMemberId) {
    this.testMemberId = testMemberId;
  }

  public void setTestCorrelationId(String testCorrelationId) {
    this.testCorrelationId = testCorrelationId;
  }

  public void setMajorVersion(String majorVersion) {
    this.majorVersion = majorVersion;
  }

  public void setSecureMsPrefixes(String secureMsPrefixes) {
    this.secureMsPrefixes = secureMsPrefixes;
  }
}
