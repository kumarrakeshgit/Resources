package com.velocityfrequentflyer.ms.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;

public class DependentRequiredValidator implements ConstraintValidator<DependentRequired, Object> {

  private String dependentProperty;
  private String dependentValue;
  private String requiredProperty;

  @Override
  public void initialize(DependentRequired constraintAnnotation) {
    dependentProperty = constraintAnnotation.dependentProperty();
    dependentValue = constraintAnnotation.dependentValue();
    requiredProperty = constraintAnnotation.requiredProperty();
  }

  @Override
  public boolean isValid(Object object, ConstraintValidatorContext ctx) {
    BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(object);
    Object depProp = wrapper.getPropertyValue(dependentProperty);
    if (depProp == null) {
      return true;
    }
    boolean depVal = depProp.equals(dependentValue);
    if (!depVal) {
      return true;
    }
    Object reqProp = wrapper.getPropertyValue(requiredProperty);
    return (reqProp != null && (!(reqProp instanceof String) || !((String) reqProp).isEmpty()));
  }
}
