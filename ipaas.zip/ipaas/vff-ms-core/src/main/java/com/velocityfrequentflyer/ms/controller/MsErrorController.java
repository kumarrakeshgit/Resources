package com.velocityfrequentflyer.ms.controller;

import com.velocityfrequentflyer.ms.dto.ErrorResponse;
import com.velocityfrequentflyer.ms.exception.AuthorizationException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;

@Api(tags = "Error Endpoint")
@RestController
public class MsErrorController implements ErrorController {

  private static final Logger log = LoggerFactory.getLogger(MsErrorController.class);

  @Autowired private ErrorAttributes errorAttributes;

  @ApiOperation(
      value = "Error Endpoint",
      notes = "By default /error will return microservice service information",
      nickname = "errorEndpoint")
  @RequestMapping(value = "/error", produces = "application/json")
  public ErrorResponse errorEndpoint(HttpServletRequest request, HttpServletResponse response)
      throws IOException {

    RequestAttributes requestAttributes = new ServletRequestAttributes(request);
    Throwable ex = errorAttributes.getError(requestAttributes);

    // special case for authorization errors as they raised from filter
    if (ex instanceof AuthorizationException) {
      log.error(ex.getMessage());
      response.sendError(HttpServletResponse.SC_UNAUTHORIZED, ex.getMessage());
    }

    String message = ex != null ? ex.getMessage() : "Unknown error";
    // special case for not found as exception is not raised here also
    if (response.getStatus() == 404) {
      message = "Path not found";
    }

    return new ErrorResponse.Builder().title(message).status(response.getStatus()).build();
  }

  @Override
  public String getErrorPath() {
    return "/error";
  }
}
