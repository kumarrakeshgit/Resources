package com.velocityfrequentflyer.ms.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(Include.NON_NULL)
public class Groups {
  @ApiModelProperty(notes = "Person preferred destinations based on past history")
  @JsonProperty("For You")
  private List<String> forYou = new ArrayList<String>();

  @ApiModelProperty(notes = "Domestic destinations")
  private List<String> domestic = new ArrayList<String>();

  @ApiModelProperty(notes = "International destinations")
  private List<String> international = new ArrayList<String>();

  public List<String> getForYou() {
    return forYou;
  }

  public void setForYou(List<String> personalised) {
    this.forYou = personalised;
  }

  public List<String> getDomestic() {
    return domestic;
  }

  public void setDomestic(List<String> domestic) {
    this.domestic = domestic;
  }

  public List<String> getInternational() {
    return international;
  }

  public void setInternational(List<String> international) {
    this.international = international;
  }

  @Override
  public String toString() {
    return "Groups [forYou="
        + forYou
        + ", domestic="
        + domestic
        + ", international="
        + international
        + "]";
  }
}
