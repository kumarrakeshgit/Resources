package com.velocityfrequentflyer.ms.mapping;

/**
 * @author Deniss Sudak
 * @param <Model>
 * @param <DTO>
 */
public interface Mapper<Model, DTO> {

  /**
   * Covert Domain Objects to DTO
   *
   * @param model domain model
   * @return a DTO object
   */
  DTO toDto(Model model);
}
