package com.velocityfrequentflyer.ms.exception;

public class ValidationException extends MsException {

  private static final long serialVersionUID = -1005581860841184971L;

  public ValidationException(String message, String code, String cause) {
    super(message, code, cause);
  }
}
