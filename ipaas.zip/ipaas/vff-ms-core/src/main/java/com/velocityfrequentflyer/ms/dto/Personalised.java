package com.velocityfrequentflyer.ms.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;

public class Personalised {
  @ApiModelProperty(
      notes =
          "Shows domestic and international destinations that a customer nearly has enough points to get to from their origin "
              + "Domestic - show destinations that customer has 80%-99% of the total points required for redemption. International - show destinations "
              + "that customer has 70%-99% of the total points required for redemption")
  private List<String> gettingClose = new ArrayList<String>();

  @ApiModelProperty(
      notes =
          "Shows domestic and international destinations that a customer already has enough points to get to from their origin.")
  private List<String> goNow = new ArrayList<String>();

  public List<String> getGettingClose() {
    return gettingClose;
  }

  public void setGettingClose(List<String> gettingClose) {
    this.gettingClose = gettingClose;
  }

  public List<String> getGoNow() {
    return goNow;
  }

  public void setGoNow(List<String> goNow) {
    this.goNow = goNow;
  }

  @Override
  public String toString() {
    return "Personalised [gettingClose=" + gettingClose + ", goNow=" + goNow + "]";
  }
}
