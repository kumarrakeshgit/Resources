[![Alt text](https://avatars2.githubusercontent.com/u/11023632?v=3&s=50)](http://versent.com.au/)
=========

# VFF AWS Micro Services Core Module

### Summary
The repo content hosts the base build core content for the vff micro service architecture that will allow intra-core-code calls to be made for the base platform for the micro services.

#### Purpose

There are at least two main reasons:

1. Isolate all common logic in one easy to modify place
2. To give all our microservices set of built in, out of the box capabilities

## Installation

Just include next dependency in your pom. By default it's already included in Microservices Archetype

```
    <dependency>
      <groupId>com.velocityfrequentflyer.ms</groupId>
      <artifactId>vff-ms-core</artifactId>
      <version>${vff-ms-core.version}</version>
    </dependency>
```

## Capabilities

### Base Controller with Error Handling

BaseController class will give your microservice basic common error handling and service base path based on application name in application properties. Just extend it in your microservices class

```
@RestController
public class ProfileController extends BaseController {
...
```
Standard /error mapping is overriden too, so now it would return 404 with proper JSON response

### Common error response format

Based on common error handling all error responses would have common simple structure

```
{
  "message": "Error message",
  "code": "Error code if necessary",
  "cause": "Underlying cause of error if specified"
}
```
All error responses are logged in BaseController with ERROR level to make it easy to trace

### Hystrix

Hystrix with dashboard is enabled by default for microservice so, to protect your downstream call you just need to add @HystrixCommand annotation to one of @Service or @Component classes making actual downstream call

```
@Component
public class ProfileService {

  @HystrixCommand
  public Profile getProfile() {
    //downstream call happening here
  }

}
```

Hystrix dashboard is available at http://localhost:9080/hystrix and Hystrix stream to monitor by default is http://localhost:9080/hystrix.stream

Hystrix can be configured in application.yml. More about Hystrix configuration https://github.com/Netflix/Hystrix/wiki/Configuration

### Eureka

Every microservice is by default Eureka client and server, so they can both register and discover itself and other services. Eureka dashboard by default is available at root path http://localhost:9080/ , but can be configured. By default microservices /info endpoint is displayed as status URL on dashboard. By default this info endpoint provided by Actuator module, but it's recommended to change it to Core /ms-info endpoint. It can be easily done in application.yml

```
eureka:
  instance:
    statusPageUrlPath: /ms-info
    healthCheckUrlPath: /ms-info
```

### Info Endpoint

By default every microservice would get /ms-info endpoint mapped and would return info like next

```
{
  name: "profile-api",
  description: "Profile API",
  environmentNumber: "99",
  environmentName: "test",
  region: "us-west-2",
  accountId: "123123",
  build: "70a6a1e",
  timestamp: "2017-12-18T11:25:49.318+11:00",
  version: "1.0-SNAPSHOT",
  commit: "afsas",
  branch: "master",
  url: "http"
}
```

### Banner

ASCII banner is located at /src/main/resources/banner.txt

#### Appendix

Repo contains core pom.xml file.
Repo contains code content to allow access for micro service code to be used.
Repo is homed/housed in collaboration with the vff-microservice-archetype repo.

#### Author information

* VFF Versent Project Team
* Sydney
